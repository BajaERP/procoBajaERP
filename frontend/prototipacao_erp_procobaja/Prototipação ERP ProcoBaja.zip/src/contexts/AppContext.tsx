import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'

export type Language = 'pt' | 'en'
export type Theme = 'light' | 'dark'

interface AppContextValue {
  language: Language
  theme: Theme
  setLanguage: (l: Language) => void
  setTheme: (t: Theme) => void
}

const AppContext = createContext<AppContextValue>({
  language: 'pt',
  theme: 'light',
  setLanguage: () => {},
  setTheme: () => {},
})

export function AppProvider({ children }: { children: ReactNode }) {
  const [language, setLang] = useState<Language>(() =>
    (localStorage.getItem('proco-lang') as Language | null) ?? 'pt'
  )
  const [theme, setThm] = useState<Theme>(() =>
    (localStorage.getItem('proco-theme') as Theme | null) ?? 'light'
  )

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
  }, [theme])

  function setLanguage(l: Language) {
    localStorage.setItem('proco-lang', l)
    setLang(l)
  }

  function setTheme(t: Theme) {
    localStorage.setItem('proco-theme', t)
    setThm(t)
  }

  return (
    <AppContext.Provider value={{ language, theme, setLanguage, setTheme }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  return useContext(AppContext)
}
