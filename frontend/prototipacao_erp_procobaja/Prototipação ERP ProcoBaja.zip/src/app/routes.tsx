import { createHashRouter, Navigate } from 'react-router-dom'
import { Shell } from './Shell'

import { WelcomePage } from '../pages/WelcomePage'
import { LoginPage } from '../pages/LoginPage'

import { CapitaoDashboard } from '../pages/CapitaoDashboard'
import { GestorDashboard } from '../pages/GestorDashboard'
import { FinanceiroDashboard } from '../pages/FinanceiroDashboard'
import { LiderDashboard } from '../pages/LiderDashboard'
import { MembroDashboard } from '../pages/MembroDashboard'
import { OrientadorDashboard } from '../pages/OrientadorDashboard'

import { EquipePage } from '../pages/EquipePage'
import { AtividadesPage } from '../pages/AtividadesPage'
import { PessoasPage } from '../pages/PessoasPage'
import { DocumentacaoPage } from '../pages/DocumentacaoPage'
import { CompeticoesPage } from '../pages/CompeticoesPage'
import { GovernancaPage } from '../pages/GovernancaPage'
import { ComponentsPage } from '../pages/ComponentsPage'
import { ConfiguracoesPage } from '../pages/ConfiguracoesPage'

export const router = createHashRouter([
  { path: '/', Component: WelcomePage },
  { path: '/login', Component: LoginPage },
  {
    path: '/app',
    Component: Shell,
    children: [
      { index: true, element: <Navigate to="/app/capitao" replace /> },
      { path: 'capitao', Component: CapitaoDashboard },
      { path: 'gestor', Component: GestorDashboard },
      { path: 'financeiro-dash', Component: FinanceiroDashboard },
      { path: 'lider', Component: LiderDashboard },
      { path: 'membro', Component: MembroDashboard },
      { path: 'orientador', Component: OrientadorDashboard },
      { path: 'equipe', Component: EquipePage },
      { path: 'atividades', Component: AtividadesPage },
      { path: 'financeiro', Component: FinanceiroDashboard },
      { path: 'pessoas', Component: PessoasPage },
      { path: 'documentacao', Component: DocumentacaoPage },
      { path: 'competicoes', Component: CompeticoesPage },
      { path: 'governanca', Component: GovernancaPage },
      { path: 'configuracoes', Component: ConfiguracoesPage },
    ],
  },
  { path: '/components', Component: ComponentsPage },
])
