import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useState, useMemo } from 'react'
import { Sidebar, type NavGroup } from '../components/Sidebar'
import { TopBar } from '../components/TopBar'
import { useT } from '../translations'
import {
  GridIcon, UsersIcon, TaskIcon, CoinIcon,
  ClockIcon, BookIcon, TrophyIcon, ShieldIcon, GearIcon,
} from '../components/icons'

export type Role = 'capitao' | 'gestor' | 'financeiro' | 'lider' | 'membro' | 'orientador'

export const ROLE_KEYS: Role[] = ['capitao', 'gestor', 'financeiro', 'lider', 'membro', 'orientador']

const DEFAULT_ROUTE: Record<Role, string> = {
  capitao: '/app/capitao',
  gestor: '/app/gestor',
  financeiro: '/app/financeiro-dash',
  lider: '/app/lider',
  membro: '/app/membro',
  orientador: '/app/orientador',
}

export function Shell() {
  const [role, setRole] = useState<Role>('capitao')
  const navigate = useNavigate()
  const location = useLocation()
  const t = useT()

  const segment = location.pathname.replace('/app/', '')

  const ROLE_LABELS = useMemo(() => ({
    capitao: t('role.capitao'),
    gestor: t('role.gestor'),
    financeiro: t('role.financeiro'),
    lider: t('role.lider'),
    membro: t('role.membro'),
    orientador: t('role.orientador'),
  }), [t])

  const ROUTE_LABELS: Record<string, string> = useMemo(() => ({
    capitao: t('route.dashboard'),
    gestor: t('route.dashboard'),
    'financeiro-dash': t('route.dashboard'),
    lider: t('route.dashboard'),
    membro: t('route.dashboard'),
    orientador: t('route.dashboard'),
    equipe: t('route.equipe'),
    atividades: t('route.atividades'),
    financeiro: t('route.financeiro'),
    pessoas: t('route.pessoas'),
    documentacao: t('route.documentacao'),
    competicoes: t('route.competicoes'),
    governanca: t('route.governanca'),
    configuracoes: t('route.configuracoes'),
  }), [t])

  const NAV_BY_ROLE: Record<Role, NavGroup[]> = useMemo(() => ({
    capitao: [
      { group: t('nav.group.geral'), items: [{ id: 'capitao', label: t('nav.dashboard'), icon: GridIcon }] },
      {
        group: t('nav.group.gestao'), items: [
          { id: 'equipe', label: t('nav.equipe'), icon: UsersIcon },
          { id: 'atividades', label: t('nav.atividades'), icon: TaskIcon },
          { id: 'financeiro', label: t('nav.financeiro'), icon: CoinIcon },
          { id: 'pessoas', label: t('nav.pessoas'), icon: ClockIcon },
        ],
      },
      {
        group: t('nav.group.projeto'), items: [
          { id: 'documentacao', label: t('nav.documentacao'), icon: BookIcon },
          { id: 'competicoes', label: t('nav.competicoes'), icon: TrophyIcon },
          { id: 'governanca', label: t('nav.governanca'), icon: ShieldIcon },
        ],
      },
      { group: t('nav.group.sistema'), items: [{ id: 'configuracoes', label: t('nav.configuracoes'), icon: GearIcon }] },
    ],
    gestor: [
      { group: t('nav.group.geral'), items: [{ id: 'gestor', label: t('nav.dashboard'), icon: GridIcon }] },
      {
        group: t('nav.group.gestao'), items: [
          { id: 'equipe', label: t('nav.equipe'), icon: UsersIcon },
          { id: 'atividades', label: t('nav.atividades'), icon: TaskIcon },
          { id: 'pessoas', label: t('nav.pessoas'), icon: ClockIcon },
        ],
      },
      {
        group: t('nav.group.projeto'), items: [
          { id: 'documentacao', label: t('nav.documentacao'), icon: BookIcon },
          { id: 'competicoes', label: t('nav.competicoes'), icon: TrophyIcon },
          { id: 'governanca', label: t('nav.governanca'), icon: ShieldIcon },
        ],
      },
      { group: t('nav.group.sistema'), items: [{ id: 'configuracoes', label: t('nav.configuracoes'), icon: GearIcon }] },
    ],
    financeiro: [
      { group: t('nav.group.geral'), items: [{ id: 'financeiro-dash', label: t('nav.dashboard'), icon: GridIcon }] },
      {
        group: t('nav.group.financas'), items: [
          { id: 'financeiro', label: t('nav.gestaoFinanceira'), icon: CoinIcon },
          { id: 'competicoes', label: t('nav.competicoes'), icon: TrophyIcon },
        ],
      },
      { group: t('nav.group.projeto'), items: [{ id: 'documentacao', label: t('nav.documentacao'), icon: BookIcon }] },
      { group: t('nav.group.sistema'), items: [{ id: 'configuracoes', label: t('nav.configuracoes'), icon: GearIcon }] },
    ],
    lider: [
      { group: t('nav.group.geral'), items: [{ id: 'lider', label: t('nav.dashboard'), icon: GridIcon }] },
      {
        group: t('nav.group.subsistema'), items: [
          { id: 'atividades', label: t('nav.atividades'), icon: TaskIcon },
          { id: 'pessoas', label: t('nav.pessoas'), icon: ClockIcon },
        ],
      },
      {
        group: t('nav.group.projeto'), items: [
          { id: 'documentacao', label: t('nav.documentacao'), icon: BookIcon },
          { id: 'competicoes', label: t('nav.competicoes'), icon: TrophyIcon },
        ],
      },
      { group: t('nav.group.sistema'), items: [{ id: 'configuracoes', label: t('nav.configuracoes'), icon: GearIcon }] },
    ],
    membro: [
      { group: t('nav.group.geral'), items: [{ id: 'membro', label: t('nav.dashboard'), icon: GridIcon }] },
      {
        group: t('nav.group.atividades'), items: [
          { id: 'atividades', label: t('nav.atividades'), icon: TaskIcon },
          { id: 'pessoas', label: t('nav.minhaPart'), icon: ClockIcon },
        ],
      },
      {
        group: t('nav.group.projeto'), items: [
          { id: 'documentacao', label: t('nav.documentacao'), icon: BookIcon },
          { id: 'competicoes', label: t('nav.competicoes'), icon: TrophyIcon },
        ],
      },
      { group: t('nav.group.sistema'), items: [{ id: 'configuracoes', label: t('nav.configuracoes'), icon: GearIcon }] },
    ],
    orientador: [
      {
        group: t('nav.group.consulta'), items: [
          { id: 'orientador', label: t('nav.dashboard'), icon: GridIcon },
          { id: 'equipe', label: t('nav.equipe'), icon: UsersIcon },
          { id: 'atividades', label: t('nav.atividades'), icon: TaskIcon },
          { id: 'financeiro', label: t('nav.financeiro'), icon: CoinIcon },
          { id: 'pessoas', label: t('nav.pessoas'), icon: ClockIcon },
          { id: 'documentacao', label: t('nav.documentacao'), icon: BookIcon },
          { id: 'competicoes', label: t('nav.competicoes'), icon: TrophyIcon },
          { id: 'governanca', label: t('nav.governanca'), icon: ShieldIcon },
        ],
      },
      { group: t('nav.group.sistema'), items: [{ id: 'configuracoes', label: t('nav.configuracoes'), icon: GearIcon }] },
    ],
  }), [t])

  const pageLabel = ROUTE_LABELS[segment] ?? segment

  function handleNavChange(id: string) {
    navigate(`/app/${id}`)
  }

  function handleRoleChange(next: Role) {
    setRole(next)
    navigate(DEFAULT_ROUTE[next])
  }

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-900 font-sans overflow-hidden">
      <Sidebar
        appName="Proco Baja"
        appAbbr="PB"
        nav={NAV_BY_ROLE[role]}
        activeId={segment}
        onNavChange={handleNavChange}
        user={{ initials: 'PB', name: 'Proco Baja', role: ROLE_LABELS[role] }}
        accentColor="#2563eb"
        background="#0f1729"
        devHref="#/components"
      />

      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* DEV role switcher */}
        <div className="bg-amber-50 dark:bg-amber-950/60 border-b border-amber-200 dark:border-amber-900 px-6 py-1.5 flex items-center gap-2 shrink-0 overflow-x-auto">
          <span className="text-[11px] font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wider shrink-0">
            {t('dev.role')}:
          </span>
          {ROLE_KEYS.map((r) => (
            <button
              key={r}
              onClick={() => handleRoleChange(r)}
              className={`shrink-0 text-xs font-medium px-2.5 py-1 rounded transition-colors ${
                role === r
                  ? 'bg-amber-500 text-white'
                  : 'text-amber-700 dark:text-amber-400 hover:bg-amber-100 dark:hover:bg-amber-900/50'
              }`}
            >
              {ROLE_LABELS[r]}
            </button>
          ))}
        </div>

        <TopBar
          breadcrumbs={[{ label: 'Proco Baja' }, { label: pageLabel }]}
          title={pageLabel}
          showSearch
          searchPlaceholder={t('topbar.search')}
          showNotifications
          hasNotifications
          showHelp
          user={{ initials: 'PB', name: 'Usuário' }}
        />

        <main className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-900">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
