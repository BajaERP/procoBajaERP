// Gestão de Documentação
// Roles: all (Capitão/Gestor can manage, others read+upload)

type Role = string
import { ReadOnlyBanner, ScreenNote } from './EquipePage'

const DOCUMENTOS = [
  { id: 'D001', nome: 'Relatório Técnico Sprint 3.pdf', subsistema: 'Chassis', tipo: 'Relatório', tamanho: '2,4 MB', atualizado: '15 set 2026', autor: 'Thiago Alves', drive: true },
  { id: 'D002', nome: 'Planilha de Peças v4.xlsx', subsistema: 'Estoque', tipo: 'Planilha', tamanho: '840 KB', atualizado: '20 set 2026', autor: 'Ana Souza', drive: true },
  { id: 'D003', nome: 'Memorial de Cálculo – Dinâmica.pdf', subsistema: 'Dinâmica', tipo: 'Cálculo', tamanho: '5,1 MB', atualizado: '18 set 2026', autor: 'Carla Mendes', drive: true },
  { id: 'D004', nome: 'Ata Reunião 23-09-2026.pdf', subsistema: 'Gestão', tipo: 'Ata', tamanho: '120 KB', atualizado: '23 set 2026', autor: 'Eduarda Pires', drive: true },
  { id: 'D005', nome: 'Cronograma Competição SAE.pdf', subsistema: 'Gestão', tipo: 'Cronograma', tamanho: '340 KB', atualizado: '10 set 2026', autor: 'Rafael Torres', drive: true },
  { id: 'D006', nome: 'Esquema Elétrico v2.pdf', subsistema: 'Elétrica', tipo: 'Esquema', tamanho: '1,8 MB', atualizado: '05 set 2026', autor: 'Diego Costa', drive: true },
]

const TIPO_COLOR: Record<string, string> = {
  Relatório: 'bg-blue-50 text-blue-700',
  Planilha: 'bg-green-50 text-green-700',
  Cálculo: 'bg-violet-50 text-violet-700',
  Ata: 'bg-slate-100 text-slate-600',
  Cronograma: 'bg-amber-50 text-amber-700',
  Esquema: 'bg-indigo-50 text-indigo-700',
}

const SUBSISTEMAS_FILTER = ['Todos', 'Chassis', 'Motor', 'Dinâmica', 'TI', 'Elétrica', 'Gestão', 'Estoque']

interface Props { role?: Role }

export function DocumentacaoPage({ role }: Props) {
  const readOnly = role === 'orientador'
  const canManage = role === 'capitao' || role === 'gestor'

  return (
    <div className="p-6 space-y-6">
      {readOnly && <ReadOnlyBanner />}

      {/* Google Drive notice */}
      <div className="bg-slate-50 border border-slate-200 rounded-lg px-5 py-4 flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0">
          <span className="text-[11px] font-bold text-slate-500">GD</span>
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-slate-700">Armazenamento via Google Drive</p>
          <p className="text-xs text-slate-400 mt-0.5">Os documentos são armazenados no Google Drive da equipe. Esta tela permite associá-los a subsistemas, atividades e competições.</p>
        </div>
        <button className="shrink-0 text-xs font-medium px-3 py-1.5 rounded border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 transition-colors" disabled>
          Abrir Drive ↗
        </button>
      </div>

      {/* Header */}
      <div className="flex flex-wrap items-center gap-3">
        <select className="px-3 py-2 rounded-md border border-slate-200 bg-white text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-400/30">
          {SUBSISTEMAS_FILTER.map((s) => <option key={s}>{s}</option>)}
        </select>
        <select className="px-3 py-2 rounded-md border border-slate-200 bg-white text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-400/30">
          <option>Todos os tipos</option>
          {Object.keys(TIPO_COLOR).map((t) => <option key={t}>{t}</option>)}
        </select>
        <div className="flex-1" />
        {!readOnly && (
          <button className="text-xs font-medium px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors" disabled>
            + Vincular documento
          </button>
        )}
      </div>

      {/* Tabela */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
              <th className="px-5 py-3 text-left">Documento</th>
              <th className="px-5 py-3 text-left">Tipo</th>
              <th className="px-5 py-3 text-left">Subsistema</th>
              <th className="px-5 py-3 text-left">Autor</th>
              <th className="px-5 py-3 text-left">Atualizado</th>
              <th className="px-5 py-3 text-right">Tamanho</th>
              <th className="px-5 py-3" />
            </tr>
          </thead>
          <tbody>
            {DOCUMENTOS.map((d) => (
              <tr key={d.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-6 h-6 rounded bg-slate-100 flex items-center justify-center shrink-0">
                      <span className="text-[9px] font-bold text-slate-400 uppercase">{d.nome.split('.').pop()}</span>
                    </div>
                    <span className="text-xs font-medium text-slate-700 truncate max-w-[200px]">{d.nome}</span>
                  </div>
                </td>
                <td className="px-5 py-3">
                  <span className={`inline-flex px-2 py-0.5 rounded text-[11px] font-medium ${TIPO_COLOR[d.tipo] ?? 'bg-slate-100 text-slate-500'}`}>{d.tipo}</span>
                </td>
                <td className="px-5 py-3 text-xs text-slate-400">{d.subsistema}</td>
                <td className="px-5 py-3 text-xs text-slate-400">{d.autor}</td>
                <td className="px-5 py-3 text-xs text-slate-400 whitespace-nowrap">{d.atualizado}</td>
                <td className="px-5 py-3 text-right text-xs font-mono text-slate-400">{d.tamanho}</td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2 justify-end">
                    <button className="text-xs text-blue-500 hover:text-blue-700">Abrir ↗</button>
                    {canManage && <button className="text-xs text-slate-400 hover:text-slate-600">Editar</button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ScreenNote>
        Esta tela incluirá: integração com Google Drive, upload e vínculo de documentos a subsistemas/atividades/competições, controle de versões e permissões por documento.
      </ScreenNote>
    </div>
  )
}
