import { CoinIcon, PeopleIcon, TruckIcon } from '../components/icons'

const KPI_CARDS = [
  { label: 'Total Revenue', value: '$4,821,390', delta: '+12.4%', up: true, sub: 'vs last quarter' },
  { label: 'Operating Expenses', value: '$1,204,870', delta: '-3.1%', up: true, sub: 'vs last quarter' },
  { label: 'Open Purchase Orders', value: '247', delta: '+18', up: false, sub: 'this month' },
  { label: 'Active Employees', value: '1,438', delta: '+23', up: true, sub: 'headcount' },
]

const RECENT_TRANSACTIONS = [
  { id: 'INV-2024-0892', vendor: 'Bosch Industrial Supply', amount: '$48,200', date: 'Sep 23, 2026', status: 'Approved', type: 'Purchase Order' },
  { id: 'INV-2024-0891', vendor: 'SAP License Renewal', amount: '$124,000', date: 'Sep 22, 2026', status: 'Pending', type: 'Software' },
  { id: 'INV-2024-0890', vendor: 'DHL Freight Services', amount: '$8,740', date: 'Sep 21, 2026', status: 'Approved', type: 'Logistics' },
  { id: 'INV-2024-0889', vendor: 'Office Depot B2B', amount: '$3,210', date: 'Sep 20, 2026', status: 'Paid', type: 'Supplies' },
  { id: 'INV-2024-0888', vendor: 'Siemens AG Contract', amount: '$290,500', date: 'Sep 19, 2026', status: 'Under Review', type: 'Equipment' },
  { id: 'INV-2024-0887', vendor: 'AWS Enterprise', amount: '$22,800', date: 'Sep 18, 2026', status: 'Paid', type: 'Cloud' },
]

const ALERTS = [
  { level: 'critical', msg: 'Warehouse C inventory below reorder threshold: Steel Coil Grade 304', time: '2h ago' },
  { level: 'warning', msg: '14 employee contracts expiring within 30 days — HR action required', time: '4h ago' },
  { level: 'info', msg: 'Q3 financial close: 3 days remaining to reconcile ledger entries', time: '6h ago' },
  { level: 'info', msg: 'Payroll run scheduled for Sep 28 — approve by Sep 26', time: '1d ago' },
]

const MODULE_HEALTH = [
  { name: 'Finance', pct: 98, color: '#22c55e' },
  { name: 'Inventory', pct: 74, color: '#f59e0b' },
  { name: 'HR', pct: 91, color: '#22c55e' },
  { name: 'Procurement', pct: 87, color: '#22c55e' },
  { name: 'Payroll', pct: 100, color: '#22c55e' },
]

const STATUS_COLOR: Record<string, string> = {
  Approved: 'bg-green-50 text-green-700',
  Pending: 'bg-amber-50 text-amber-700',
  Paid: 'bg-blue-50 text-blue-700',
  'Under Review': 'bg-slate-100 text-slate-600',
}

const ALERT_COLOR: Record<string, string> = {
  critical: 'bg-red-500',
  warning: 'bg-amber-400',
  info: 'bg-blue-400',
}

export function DashboardPage() {
  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {KPI_CARDS.map((card) => (
          <div key={card.label} className="bg-white rounded-lg border border-slate-200 p-5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{card.label}</p>
            <p className="text-2xl font-semibold text-slate-900 mt-2 font-mono">{card.value}</p>
            <div className="flex items-center gap-1.5 mt-2">
              <span className={`text-xs font-medium ${card.up ? 'text-green-600' : 'text-red-500'}`}>{card.delta}</span>
              <span className="text-xs text-slate-400">{card.sub}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-lg border border-slate-200">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-800">Recent Transactions</h2>
            <button className="text-xs text-blue-600 hover:underline font-medium">View all</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                  <th className="px-5 py-3 text-left">ID</th>
                  <th className="px-5 py-3 text-left">Vendor</th>
                  <th className="px-5 py-3 text-left">Type</th>
                  <th className="px-5 py-3 text-right">Amount</th>
                  <th className="px-5 py-3 text-left">Date</th>
                  <th className="px-5 py-3 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {RECENT_TRANSACTIONS.map((tx) => (
                  <tr key={tx.id} className="border-b border-slate-50 hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-3 font-mono text-xs text-slate-500">{tx.id}</td>
                    <td className="px-5 py-3 text-slate-700 font-medium whitespace-nowrap">{tx.vendor}</td>
                    <td className="px-5 py-3 text-slate-400 text-xs">{tx.type}</td>
                    <td className="px-5 py-3 text-right font-mono text-slate-800 font-medium">{tx.amount}</td>
                    <td className="px-5 py-3 text-slate-400 text-xs whitespace-nowrap">{tx.date}</td>
                    <td className="px-5 py-3">
                      <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLOR[tx.status]}`}>
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="bg-white rounded-lg border border-slate-200 p-5">
            <h2 className="text-sm font-semibold text-slate-800 mb-4">Module Health</h2>
            <div className="space-y-3">
              {MODULE_HEALTH.map((m) => (
                <div key={m.name}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-600 font-medium">{m.name}</span>
                    <span className="font-mono text-slate-500">{m.pct}%</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${m.pct}%`, background: m.color }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg border border-slate-200 p-5 flex-1">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold text-slate-800">System Alerts</h2>
              <span className="text-[11px] bg-red-50 text-red-600 font-medium px-1.5 py-0.5 rounded">1 critical</span>
            </div>
            <div className="space-y-3">
              {ALERTS.map((a, i) => (
                <div key={i} className="flex gap-2.5">
                  <div className={`mt-1 w-2 h-2 rounded-full shrink-0 ${ALERT_COLOR[a.level]}`} />
                  <div>
                    <p className="text-xs text-slate-700 leading-snug">{a.msg}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">{a.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <QuickAction icon={<CoinIcon />} title="New Journal Entry" desc="Post manual GL transactions" color="bg-blue-600" />
        <QuickAction icon={<TruckIcon />} title="Create Purchase Order" desc="Initiate procurement workflow" color="bg-indigo-600" />
        <QuickAction icon={<PeopleIcon />} title="Run Payroll" desc="Process payroll for Sep 2026" color="bg-violet-600" />
      </div>
    </div>
  )
}

function QuickAction({ icon, title, desc, color }: { icon: React.ReactNode; title: string; desc: string; color: string }) {
  return (
    <button className="bg-white rounded-lg border border-slate-200 p-5 flex items-center gap-4 text-left hover:border-blue-300 hover:shadow-sm transition-all group">
      <div className={`w-9 h-9 rounded-lg ${color} flex items-center justify-center text-white shrink-0`}>{icon}</div>
      <div>
        <p className="text-sm font-semibold text-slate-800 group-hover:text-blue-700 transition-colors">{title}</p>
        <p className="text-xs text-slate-400 mt-0.5">{desc}</p>
      </div>
    </button>
  )
}
