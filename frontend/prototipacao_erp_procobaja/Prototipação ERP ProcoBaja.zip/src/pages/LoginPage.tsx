import { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { LogoMark } from '../components/Logo'

export function LoginPage() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [animating, setAnimating] = useState(false)
  const [scale, setScale] = useState(1)
  const emailRef = useRef<HTMLInputElement>(null)

  useEffect(() => { emailRef.current?.focus() }, [])

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!email || !password) return

    // Start zoom animation
    setAnimating(true)
    // Defer scale bump so transition fires (needs two frames)
    requestAnimationFrame(() => requestAnimationFrame(() => setScale(80)))
    // Navigate after animation completes
    setTimeout(() => navigate('/app/capitao'), 750)
  }

  return (
    <div className="min-h-screen bg-[#0a0f1e] flex items-center justify-center font-sans px-6">
      {/* Form card */}
      <div className="w-full max-w-xs space-y-8">
        {/* Logo */}
        <div className="flex flex-col items-center gap-3">
          <LogoMark size={72} />
          <p className="text-white/40 text-xs tracking-widest uppercase">Acesse sua conta</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            ref={emailRef}
            type="text"
            placeholder="E-mail ou usuário"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder-white/25 focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500/40 transition-all"
          />
          <input
            type="password"
            placeholder="Senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder-white/25 focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500/40 transition-all"
          />
          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm transition-colors shadow-lg shadow-blue-900/40 mt-1"
          >
            Entrar
          </button>
        </form>
      </div>

      {/* Logo zoom overlay — mounts on submit, zooms to fill screen */}
      {animating && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50 overflow-hidden"
          style={{ background: '#0a0f1e' }}
        >
          <div
            style={{
              transform: `scale(${scale})`,
              transition: 'transform 0.7s cubic-bezier(0.4, 0, 0.1, 1)',
              willChange: 'transform',
            }}
          >
            <LogoMark size={80} />
          </div>
        </div>
      )}
    </div>
  )
}
