import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { LogoMark } from '../components/Logo'

export function WelcomePage() {
  const navigate = useNavigate()

  // Any click or keypress goes to login
  useEffect(() => {
    const go = () => navigate('/login')
    window.addEventListener('keydown', go)
    return () => window.removeEventListener('keydown', go)
  }, [navigate])

  return (
    <div
      onClick={() => navigate('/login')}
      className="min-h-screen bg-[#0a0f1e] flex flex-col items-center justify-center cursor-pointer select-none font-sans"
    >
      {/* Subtle radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 60% 50% at 50% 50%, rgba(37,99,235,0.12) 0%, transparent 70%)',
        }}
      />

      <div className="relative flex flex-col items-center gap-6">
        <LogoMark size={120} />

        <div className="text-center">
          <p className="text-white text-2xl font-bold tracking-[0.15em]">PROCO BAJA</p>
          <p className="text-white/30 text-sm tracking-widest uppercase mt-1 font-medium">Sistema de Gestão</p>
        </div>
      </div>

      {/* Tap hint */}
      <p className="absolute bottom-10 text-white/15 text-xs tracking-widest uppercase animate-pulse">
        Toque para continuar
      </p>
    </div>
  )
}
