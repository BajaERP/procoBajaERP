import { useState } from 'react'

const KPI = [
  { label: 'Receita Total', value: 'R$ 48.200', delta: '+8,3%', up: true, sub: 'vs mês anterior' },
  { label: 'Despesas', value: 'R$ 21.450', delta: '+2,1%', up: false, sub: 'vs mês anterior' },
  { label: 'Saldo', value: 'R$ 26.750', delta: '+14,2%', up: true, sub: 'vs mês anterior' },
  { label: 'Patrocínios Ativos', value: '7', delta: '+2', up: true, sub: 'este semestre' },
]

const TRANSACOES = [
  { id: 'TX-001', descricao: 'Patrocínio Empresa Alpha', valor: 'R$ 15.000', data: '20 set 2026', tipo: 'Entrada', categoria: 'Patrocínio' },
  { id: 'TX-002', descricao: 'Compra de materiais – chassis', valor: 'R$ 8.400', data: '18 set 2026', tipo: 'Saída', categoria: 'Materiais' },
  { id: 'TX-003', descricao: 'Inscrição competição regional', valor: 'R$ 1.200', data: '15 set 2026', tipo: 'Saída', categoria: 'Competição' },
  { id: 'TX-004', descricao: 'Doação de ex-aluno', valor: 'R$ 3.000', data: '12 set 2026', tipo: 'Entrada', categoria: 'Doação' },
  { id: 'TX-005', descricao: 'Ferramentas oficina', valor: 'R$ 760', data: '10 set 2026', tipo: 'Saída', categoria: 'Materiais' },
  { id: 'TX-006', descricao: 'Patrocínio Empresa Beta', valor: 'R$ 8.000', data: '05 set 2026', tipo: 'Entrada', categoria: 'Patrocínio' },
]

const TIPO_COLOR: Record<string, string> = {
  Entrada: 'bg-green-50 text-green-700',
  Saída: 'bg-red-50 text-red-600',
}

type NovaTransacao = {
  descricao: string
  valor: string
  tipo: 'Entrada' | 'Saída'
  categoria: string
  data: string
}

const CATEGORIAS = ['Patrocínio', 'Doação', 'Materiais', 'Competição', 'Transporte', 'Outros']

export function FinanceiroDashboard() {
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState<NovaTransacao>({
    descricao: '',
    valor: '',
    tipo: 'Entrada',
    categoria: 'Patrocínio',
    data: '',
  })
  const [transacoes, setTransacoes] = useState(TRANSACOES)
  const [sucesso, setSucesso] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const nova = {
      id: `TX-${String(transacoes.length + 1).padStart(3, '0')}`,
      ...form,
    }
    setTransacoes([nova, ...transacoes])
    setForm({ descricao: '', valor: '', tipo: 'Entrada', categoria: 'Patrocínio', data: '' })
    setShowForm(false)
    setSucesso(true)
    setTimeout(() => setSucesso(false), 3000)
  }

  return (
    <div className="p-6 space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {KPI.map((k) => (
          <div key={k.label} className="bg-white rounded-lg border border-slate-200 p-5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{k.label}</p>
            <p className="text-2xl font-semibold text-slate-900 mt-2 font-mono">{k.value}</p>
            <div className="flex items-center gap-1.5 mt-2">
              <span className={`text-xs font-medium ${k.up ? 'text-green-600' : 'text-red-500'}`}>{k.delta}</span>
              <span className="text-xs text-slate-400">{k.sub}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Toast */}
      {sucesso && (
        <div className="bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3 rounded-lg flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-green-500 shrink-0" />
          Transação registrada com sucesso.
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tabela */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-slate-200">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-800">Transações Recentes</h2>
            <button
              onClick={() => setShowForm((v) => !v)}
              className="text-xs font-medium px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors"
            >
              {showForm ? 'Cancelar' : '+ Registrar transação'}
            </button>
          </div>

          {/* Inline form */}
          {showForm && (
            <form onSubmit={handleSubmit} className="px-5 py-4 border-b border-slate-100 bg-slate-50 grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="block text-xs font-medium text-slate-600 mb-1">Descrição</label>
                <input
                  required
                  value={form.descricao}
                  onChange={(e) => setForm({ ...form, descricao: e.target.value })}
                  className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30"
                  placeholder="Ex: Patrocínio empresa X"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Valor (R$)</label>
                <input
                  required
                  value={form.valor}
                  onChange={(e) => setForm({ ...form, valor: e.target.value })}
                  className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30"
                  placeholder="Ex: 5.000"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Data</label>
                <input
                  required
                  type="date"
                  value={form.data}
                  onChange={(e) => setForm({ ...form, data: e.target.value })}
                  className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Tipo</label>
                <select
                  value={form.tipo}
                  onChange={(e) => setForm({ ...form, tipo: e.target.value as 'Entrada' | 'Saída' })}
                  className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30 bg-white"
                >
                  <option>Entrada</option>
                  <option>Saída</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Categoria</label>
                <select
                  value={form.categoria}
                  onChange={(e) => setForm({ ...form, categoria: e.target.value })}
                  className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30 bg-white"
                >
                  {CATEGORIAS.map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="col-span-2 flex justify-end gap-2">
                <button type="button" onClick={() => setShowForm(false)} className="text-xs px-3 py-1.5 rounded border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors">Cancelar</button>
                <button type="submit" className="text-xs px-4 py-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 transition-colors font-medium">Salvar</button>
              </div>
            </form>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                  <th className="px-5 py-3 text-left">ID</th>
                  <th className="px-5 py-3 text-left">Descrição</th>
                  <th className="px-5 py-3 text-left">Categoria</th>
                  <th className="px-5 py-3 text-right">Valor</th>
                  <th className="px-5 py-3 text-left">Data</th>
                  <th className="px-5 py-3 text-left">Tipo</th>
                </tr>
              </thead>
              <tbody>
                {transacoes.map((tx) => (
                  <tr key={tx.id} className="border-b border-slate-50 hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-3 font-mono text-xs text-slate-400">{tx.id}</td>
                    <td className="px-5 py-3 text-slate-700 font-medium">{tx.descricao}</td>
                    <td className="px-5 py-3 text-slate-400 text-xs">{tx.categoria}</td>
                    <td className="px-5 py-3 text-right font-mono text-slate-800 font-medium">{tx.valor}</td>
                    <td className="px-5 py-3 text-slate-400 text-xs whitespace-nowrap">{tx.data}</td>
                    <td className="px-5 py-3">
                      <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${TIPO_COLOR[tx.tipo]}`}>{tx.tipo}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Resumo por categoria */}
        <div className="space-y-4">
          <div className="bg-white rounded-lg border border-slate-200 p-5">
            <h2 className="text-sm font-semibold text-slate-800 mb-4">Gastos por Categoria</h2>
            <div className="space-y-3">
              {[
                { nome: 'Materiais', valor: 9160, total: 21450 },
                { nome: 'Competição', valor: 1200, total: 21450 },
                { nome: 'Transporte', valor: 4800, total: 21450 },
                { nome: 'Outros', valor: 6290, total: 21450 },
              ].map((cat) => {
                const pct = Math.round((cat.valor / cat.total) * 100)
                return (
                  <div key={cat.nome}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-600 font-medium">{cat.nome}</span>
                      <span className="font-mono text-slate-500">{pct}%</span>
                    </div>
                    <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-blue-500" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          <div className="bg-white rounded-lg border border-slate-200 p-5">
            <h2 className="text-sm font-semibold text-slate-800 mb-3">Entradas × Saídas</h2>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-green-500" />Entradas</span>
                <span className="font-mono font-semibold text-green-700">R$ 26.000</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-red-400" />Saídas</span>
                <span className="font-mono font-semibold text-red-600">R$ 10.360</span>
              </div>
              <div className="border-t border-slate-100 pt-2 flex items-center justify-between text-sm font-semibold">
                <span className="text-slate-700">Saldo do mês</span>
                <span className="font-mono text-slate-900">R$ 15.640</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
