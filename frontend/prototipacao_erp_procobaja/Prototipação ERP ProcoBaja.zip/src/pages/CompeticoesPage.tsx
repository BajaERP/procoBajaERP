// Gestão de Competições e Eventos
// Roles: Capitão, Gestor (full manage), Financeiro (gastos), Líder, Membro (participação), Orientador (read-only)

type Role = string
import { ReadOnlyBanner, ScreenNote } from './EquipePage'

interface Competicao {
  id: string
  nome: string
  local: string
  data: string
  tipo: 'Competição' | 'Evento' | 'Workshop'
  status: 'Próximo' | 'Em andamento' | 'Concluído' | 'Cancelado'
  participantes: number
  gastos: string
  resultado?: string
}

const COMPETICOES: Competicao[] = [
  { id: 'C001', nome: 'SAE Brasil Baja 2026 – Etapa Norte', local: 'Belém, PA', data: '15–18 out 2026', tipo: 'Competição', status: 'Próximo', participantes: 8, gastos: 'R$ 12.400', resultado: undefined },
  { id: 'C002', nome: 'Baja Nordeste 2026', local: 'Recife, PE', data: '22–24 ago 2026', tipo: 'Competição', status: 'Concluído', participantes: 6, gastos: 'R$ 8.200', resultado: '4º lugar – Enduro' },
  { id: 'C003', nome: 'Workshop Técnico UNIFOR', local: 'Fortaleza, CE', data: '10 set 2026', tipo: 'Workshop', status: 'Concluído', participantes: 12, gastos: 'R$ 0', resultado: 'Participação' },
  { id: 'C004', nome: 'SAE Brasil Baja 2026 – Etapa Sul', local: 'Curitiba, PR', data: '03–06 dez 2026', tipo: 'Competição', status: 'Próximo', participantes: 0, gastos: 'R$ 0', resultado: undefined },
]

const TIPO_COLOR: Record<string, string> = {
  Competição: 'bg-blue-50 text-blue-700',
  Evento: 'bg-violet-50 text-violet-700',
  Workshop: 'bg-amber-50 text-amber-700',
}

const STATUS_COLOR: Record<string, string> = {
  'Próximo': 'bg-blue-50 text-blue-600',
  'Em andamento': 'bg-green-50 text-green-700',
  'Concluído': 'bg-slate-100 text-slate-500',
  'Cancelado': 'bg-red-50 text-red-500',
}

interface Props { role?: Role }

export function CompeticoesPage({ role }: Props) {
  const readOnly = role === 'orientador'
  const canManage = role === 'capitao' || role === 'gestor'
  const showFinanceiro = role === 'capitao' || role === 'gestor' || role === 'financeiro' || role === 'orientador'

  return (
    <div className="p-6 space-y-6">
      {readOnly && <ReadOnlyBanner />}

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Competições', value: COMPETICOES.filter((c) => c.tipo === 'Competição').length },
          { label: 'Próximas', value: COMPETICOES.filter((c) => c.status === 'Próximo').length },
          { label: 'Concluídas', value: COMPETICOES.filter((c) => c.status === 'Concluído').length },
          ...(showFinanceiro ? [{ label: 'Gasto Total', value: 'R$ 20.600' }] : [{ label: 'Participações', value: 14 }]),
        ].map((k) => (
          <div key={k.label} className="bg-white rounded-lg border border-slate-200 p-5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{k.label}</p>
            <p className="text-2xl font-semibold text-slate-900 mt-2 font-mono">{k.value}</p>
          </div>
        ))}
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-slate-800">Competições e Eventos</h2>
        {canManage && (
          <button className="text-xs font-medium px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors" disabled>
            + Cadastrar evento
          </button>
        )}
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {COMPETICOES.map((c) => (
          <div key={c.id} className="bg-white rounded-lg border border-slate-200 p-5">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <p className="text-sm font-semibold text-slate-800">{c.nome}</p>
                <p className="text-xs text-slate-400 mt-0.5">{c.local} · {c.data}</p>
              </div>
              <div className="flex flex-col items-end gap-1 shrink-0">
                <span className={`text-[11px] font-medium px-2 py-0.5 rounded ${TIPO_COLOR[c.tipo]}`}>{c.tipo}</span>
                <span className={`text-[11px] font-medium px-2 py-0.5 rounded ${STATUS_COLOR[c.status]}`}>{c.status}</span>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs text-slate-500">
              <span>{c.participantes > 0 ? `${c.participantes} participantes` : 'Participantes a definir'}</span>
              {showFinanceiro && <span className="font-mono font-medium text-slate-700">{c.gastos}</span>}
            </div>

            {c.resultado && (
              <div className="mt-3 pt-3 border-t border-slate-100">
                <p className="text-xs text-slate-600"><span className="font-semibold">Resultado:</span> {c.resultado}</p>
              </div>
            )}

            {!readOnly && (
              <div className="mt-3 flex gap-2">
                {(canManage) && <button className="text-xs text-blue-500 hover:text-blue-700" disabled>Editar</button>}
                <button className="text-xs text-slate-400 hover:text-slate-600" disabled>Ver documentos</button>
                {(role === 'membro' || role === 'lider') && c.status === 'Próximo' && (
                  <button className="text-xs text-blue-500 hover:text-blue-700" disabled>Confirmar participação</button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      <ScreenNote>
        Esta tela incluirá: cadastro detalhado de competições e eventos, lista de participantes com confirmação, controle de gastos por evento, resultados e documentos vinculados.
      </ScreenNote>
    </div>
  )
}
