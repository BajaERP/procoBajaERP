import { useState } from 'react'

type Cargo = 'Capitão' | 'Gestor' | 'Financeiro' | 'Líder' | 'Membro' | 'Orientador'
type Status = 'Ativo' | 'Inativo' | 'Pendente'

interface Usuario {
  id: string
  nome: string
  email: string
  cargo: Cargo
  subsistema: string
  status: Status
  ingresso: string
}

const USUARIOS_INICIAIS: Usuario[] = [
  { id: 'U001', nome: 'Rafael Torres', email: 'rafael.torres@procobaja.com', cargo: 'Capitão', subsistema: 'Gestão', status: 'Ativo', ingresso: '01 fev 2024' },
  { id: 'U002', nome: 'Eduarda Pires', email: 'eduarda.pires@procobaja.com', cargo: 'Gestor', subsistema: 'Gestão', status: 'Ativo', ingresso: '01 fev 2024' },
  { id: 'U003', nome: 'Marcos Henrique', email: 'marcos.h@procobaja.com', cargo: 'Financeiro', subsistema: 'Financeiro', status: 'Ativo', ingresso: '10 mar 2025' },
  { id: 'U004', nome: 'Carla Mendes', email: 'carla.mendes@procobaja.com', cargo: 'Líder', subsistema: 'Dinâmica', status: 'Ativo', ingresso: '05 ago 2024' },
  { id: 'U005', nome: 'Thiago Alves', email: 'thiago.alves@procobaja.com', cargo: 'Líder', subsistema: 'Chassis', status: 'Ativo', ingresso: '05 ago 2024' },
  { id: 'U006', nome: 'Ana Souza', email: 'ana.souza@procobaja.com', cargo: 'Membro', subsistema: 'Chassis', status: 'Ativo', ingresso: '10 mar 2025' },
  { id: 'U007', nome: 'Bruno Lima', email: 'bruno.lima@procobaja.com', cargo: 'Membro', subsistema: 'Motor', status: 'Ativo', ingresso: '10 mar 2025' },
  { id: 'U008', nome: 'Felipe Rocha', email: 'felipe.rocha@procobaja.com', cargo: 'Membro', subsistema: 'Chassis', status: 'Inativo', ingresso: '10 mar 2025' },
  { id: 'U009', nome: 'Prof. Antônio Cruz', email: 'antonio.cruz@universidade.br', cargo: 'Orientador', subsistema: '—', status: 'Ativo', ingresso: '01 jan 2024' },
  { id: 'U010', nome: 'Larissa Mota', email: 'larissa.mota@procobaja.com', cargo: 'Membro', subsistema: 'TI', status: 'Pendente', ingresso: '20 set 2026' },
]

const SUBSISTEMAS = [
  { nome: 'Chassis', lider: 'Thiago Alves', membros: 3, tarefas: 12, concluidas: 7 },
  { nome: 'Motor', lider: '—', membros: 2, tarefas: 8, concluidas: 5 },
  { nome: 'Dinâmica', lider: 'Carla Mendes', membros: 2, tarefas: 6, concluidas: 6 },
  { nome: 'TI', lider: '—', membros: 1, tarefas: 4, concluidas: 2 },
  { nome: 'Elétrica', lider: '—', membros: 0, tarefas: 0, concluidas: 0 },
]

const CARGOS: Cargo[] = ['Capitão', 'Gestor', 'Financeiro', 'Líder', 'Membro', 'Orientador']
const TODOS_SUBSISTEMAS = ['Gestão', 'Financeiro', 'Chassis', 'Motor', 'Dinâmica', 'TI', 'Elétrica', '—']

const STATUS_COLOR: Record<string, string> = {
  Ativo: 'bg-green-50 text-green-700',
  Inativo: 'bg-slate-100 text-slate-500',
  Pendente: 'bg-amber-50 text-amber-700',
}

const CARGO_COLOR: Record<string, string> = {
  Capitão: 'bg-[#0f1729] text-white',
  Gestor: 'bg-violet-50 text-violet-700',
  Financeiro: 'bg-blue-50 text-blue-700',
  Líder: 'bg-indigo-50 text-indigo-700',
  Membro: 'bg-slate-100 text-slate-600',
  Orientador: 'bg-emerald-50 text-emerald-700',
}

export function CapitaoDashboard() {
  const [usuarios, setUsuarios] = useState(USUARIOS_INICIAIS)
  const [showForm, setShowForm] = useState(false)
  const [busca, setBusca] = useState('')
  const [filtrarCargo, setFiltrarCargo] = useState<string>('Todos')
  const [sucesso, setSucesso] = useState('')
  const [form, setForm] = useState({ nome: '', email: '', cargo: 'Membro' as Cargo, subsistema: 'Chassis', ingresso: '' })
  const [editandoId, setEditandoId] = useState<string | null>(null)
  const [novoCargo, setNovoCargo] = useState<Cargo>('Membro')

  function cadastrar(e: React.FormEvent) {
    e.preventDefault()
    const novo: Usuario = {
      id: `U${String(usuarios.length + 1).padStart(3, '0')}`,
      ...form,
      status: 'Pendente',
    }
    setUsuarios([novo, ...usuarios])
    setSucesso(`${form.nome} cadastrado(a) com sucesso.`)
    setForm({ nome: '', email: '', cargo: 'Membro', subsistema: 'Chassis', ingresso: '' })
    setShowForm(false)
    setTimeout(() => setSucesso(''), 4000)
  }

  function salvarCargo(id: string) {
    setUsuarios((prev) => prev.map((u) => u.id === id ? { ...u, cargo: novoCargo } : u))
    setEditandoId(null)
  }

  function toggleStatus(id: string) {
    setUsuarios((prev) => prev.map((u) => u.id === id ? { ...u, status: u.status === 'Ativo' ? 'Inativo' : 'Ativo' } : u))
  }

  const filtrados = usuarios.filter((u) => {
    const matchBusca = u.nome.toLowerCase().includes(busca.toLowerCase()) || u.email.toLowerCase().includes(busca.toLowerCase())
    const matchCargo = filtrarCargo === 'Todos' || u.cargo === filtrarCargo
    return matchBusca && matchCargo
  })

  const ativos = usuarios.filter((u) => u.status === 'Ativo').length
  const pendentes = usuarios.filter((u) => u.status === 'Pendente').length

  return (
    <div className="p-6 space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total de Usuários', value: usuarios.length, cor: 'text-slate-900' },
          { label: 'Ativos', value: ativos, cor: 'text-green-700' },
          { label: 'Pendentes', value: pendentes, cor: 'text-amber-600' },
          { label: 'Subsistemas', value: SUBSISTEMAS.length, cor: 'text-slate-900' },
        ].map((k) => (
          <div key={k.label} className="bg-white rounded-lg border border-slate-200 p-5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{k.label}</p>
            <p className={`text-2xl font-semibold mt-2 font-mono ${k.cor}`}>{k.value}</p>
          </div>
        ))}
      </div>

      {sucesso && (
        <div className="bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3 rounded-lg flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-green-500 shrink-0" />
          {sucesso}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Usuários */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <input
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              placeholder="Buscar usuário…"
              className="flex-1 min-w-40 px-3 py-2 rounded-md border border-slate-200 bg-white text-sm text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400/30"
            />
            <select
              value={filtrarCargo}
              onChange={(e) => setFiltrarCargo(e.target.value)}
              className="px-3 py-2 rounded-md border border-slate-200 bg-white text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-400/30"
            >
              <option>Todos</option>
              {CARGOS.map((c) => <option key={c}>{c}</option>)}
            </select>
            <button
              onClick={() => setShowForm((v) => !v)}
              className="shrink-0 text-xs font-medium px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors"
            >
              {showForm ? 'Cancelar' : '+ Novo usuário'}
            </button>
          </div>

          {showForm && (
            <form onSubmit={cadastrar} className="bg-white rounded-lg border border-slate-200 p-5 grid grid-cols-2 gap-3">
              <h3 className="col-span-2 text-sm font-semibold text-slate-800">Novo Usuário</h3>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Nome</label>
                <input required value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" placeholder="Nome completo" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">E-mail</label>
                <input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" placeholder="email@procobaja.com" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Cargo</label>
                <select value={form.cargo} onChange={(e) => setForm({ ...form, cargo: e.target.value as Cargo })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-400/30">
                  {CARGOS.map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Subsistema</label>
                <select value={form.subsistema} onChange={(e) => setForm({ ...form, subsistema: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-400/30">
                  {TODOS_SUBSISTEMAS.map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Data de ingresso</label>
                <input required type="date" value={form.ingresso} onChange={(e) => setForm({ ...form, ingresso: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" />
              </div>
              <div className="col-span-2 flex justify-end gap-2">
                <button type="button" onClick={() => setShowForm(false)} className="text-xs px-3 py-1.5 rounded border border-slate-200 text-slate-600 hover:bg-slate-50">Cancelar</button>
                <button type="submit" className="text-xs px-4 py-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 font-medium">Cadastrar</button>
              </div>
            </form>
          )}

          <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-800">Usuários do Sistema</h2>
              <span className="text-xs text-slate-400">{filtrados.length} resultado{filtrados.length !== 1 ? 's' : ''}</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                    <th className="px-4 py-3 text-left">Usuário</th>
                    <th className="px-4 py-3 text-left">Cargo</th>
                    <th className="px-4 py-3 text-left">Subsistema</th>
                    <th className="px-4 py-3 text-left">Status</th>
                    <th className="px-4 py-3 text-left">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filtrados.map((u) => (
                    <tr key={u.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-xs font-semibold text-slate-600 shrink-0">
                            {u.nome.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                          </div>
                          <div>
                            <p className="font-medium text-slate-700 text-xs">{u.nome}</p>
                            <p className="text-[11px] text-slate-400">{u.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {editandoId === u.id ? (
                          <div className="flex items-center gap-1.5">
                            <select value={novoCargo} onChange={(e) => setNovoCargo(e.target.value as Cargo)} className="px-2 py-0.5 rounded border border-slate-200 text-xs bg-white focus:outline-none focus:ring-1 focus:ring-blue-400">
                              {CARGOS.map((c) => <option key={c}>{c}</option>)}
                            </select>
                            <button onClick={() => salvarCargo(u.id)} className="text-[10px] px-2 py-0.5 bg-blue-600 text-white rounded hover:bg-blue-700">✓</button>
                            <button onClick={() => setEditandoId(null)} className="text-[10px] px-2 py-0.5 bg-white border border-slate-200 text-slate-500 rounded">✕</button>
                          </div>
                        ) : (
                          <span className={`inline-flex px-2 py-0.5 rounded text-[11px] font-medium ${CARGO_COLOR[u.cargo]}`}>{u.cargo}</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-400">{u.subsistema}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex px-2 py-0.5 rounded text-[11px] font-medium ${STATUS_COLOR[u.status]}`}>{u.status}</span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button onClick={() => { setEditandoId(u.id); setNovoCargo(u.cargo) }} className="text-xs text-blue-500 hover:text-blue-700 transition-colors">Cargo</button>
                          <span className="text-slate-200">·</span>
                          <button onClick={() => toggleStatus(u.id)} className="text-xs text-slate-400 hover:text-slate-700 transition-colors">
                            {u.status === 'Ativo' ? 'Desativar' : 'Ativar'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Subsistemas */}
        <div className="space-y-4">
          <h2 className="text-sm font-semibold text-slate-800">Subsistemas</h2>
          {SUBSISTEMAS.map((s) => {
            const pct = s.tarefas > 0 ? Math.round((s.concluidas / s.tarefas) * 100) : 0
            return (
              <div key={s.nome} className="bg-white rounded-lg border border-slate-200 p-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-semibold text-slate-800">{s.nome}</p>
                  <span className="text-[11px] text-slate-400">{s.membros} membro{s.membros !== 1 ? 's' : ''}</span>
                </div>
                <p className="text-[11px] text-slate-400 mb-2">Líder: {s.lider}</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-blue-500" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">{pct}%</span>
                </div>
                <p className="text-[11px] text-slate-300 mt-1">{s.concluidas}/{s.tarefas} tarefas</p>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
