import { useState } from 'react'

interface Membro {
  id: string
  nome: string
  email: string
  subarea: string
  cargo: string
  ingresso: string
  status: 'Ativo' | 'Inativo'
}

const MEMBROS_INICIAIS: Membro[] = [
  { id: 'M001', nome: 'Ana Souza', email: 'ana.souza@procobaja.com', subarea: 'Chassis', cargo: 'Membro', ingresso: '10 mar 2025', status: 'Ativo' },
  { id: 'M002', nome: 'Bruno Lima', email: 'bruno.lima@procobaja.com', subarea: 'Motor', cargo: 'Membro', ingresso: '10 mar 2025', status: 'Ativo' },
  { id: 'M003', nome: 'Carla Mendes', email: 'carla.mendes@procobaja.com', subarea: 'Dinâmica', cargo: 'Líder de Subárea', ingresso: '05 ago 2024', status: 'Ativo' },
  { id: 'M004', nome: 'Diego Costa', email: 'diego.costa@procobaja.com', subarea: 'TI', cargo: 'Membro', ingresso: '10 mar 2025', status: 'Ativo' },
  { id: 'M005', nome: 'Eduarda Pires', email: 'eduarda.pires@procobaja.com', subarea: 'Gestão', cargo: 'Líder Geral', ingresso: '01 fev 2024', status: 'Ativo' },
  { id: 'M006', nome: 'Felipe Rocha', email: 'felipe.rocha@procobaja.com', subarea: 'Chassis', cargo: 'Membro', ingresso: '10 mar 2025', status: 'Ativo' },
  { id: 'M007', nome: 'Gabriela Nunes', email: 'gabriela.nunes@procobaja.com', subarea: 'Motor', cargo: 'Membro', ingresso: '15 jan 2025', status: 'Inativo' },
]

const SUBAREAS = ['Chassis', 'Motor', 'Dinâmica', 'TI', 'Gestão', 'Elétrica', 'Manufatura']
const CARGOS = ['Membro', 'Líder de Subárea', 'Líder Geral', 'Financeiro']

const STATUS_COLOR: Record<string, string> = {
  Ativo: 'bg-green-50 text-green-700',
  Inativo: 'bg-slate-100 text-slate-500',
}

export function RHPage() {
  const [membros, setMembros] = useState(MEMBROS_INICIAIS)
  const [showForm, setShowForm] = useState(false)
  const [busca, setBusca] = useState('')
  const [sucesso, setSucesso] = useState('')
  const [form, setForm] = useState({
    nome: '', email: '', subarea: 'Chassis', cargo: 'Membro', ingresso: '',
  })

  function cadastrar(e: React.FormEvent) {
    e.preventDefault()
    const novo: Membro = {
      id: `M${String(membros.length + 1).padStart(3, '0')}`,
      ...form,
      status: 'Ativo',
    }
    setMembros([novo, ...membros])
    setSucesso(`${form.nome} cadastrado(a) com sucesso.`)
    setForm({ nome: '', email: '', subarea: 'Chassis', cargo: 'Membro', ingresso: '' })
    setShowForm(false)
    setTimeout(() => setSucesso(''), 4000)
  }

  function toggleStatus(id: string) {
    setMembros((prev) => prev.map((m) => m.id === id ? { ...m, status: m.status === 'Ativo' ? 'Inativo' : 'Ativo' } : m))
  }

  const filtrados = membros.filter(
    (m) =>
      m.nome.toLowerCase().includes(busca.toLowerCase()) ||
      m.subarea.toLowerCase().includes(busca.toLowerCase()) ||
      m.cargo.toLowerCase().includes(busca.toLowerCase())
  )

  const ativos = membros.filter((m) => m.status === 'Ativo').length

  return (
    <div className="p-6 space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-lg border border-slate-200 p-5">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Total de Membros</p>
          <p className="text-2xl font-semibold text-slate-900 mt-2 font-mono">{membros.length}</p>
        </div>
        <div className="bg-white rounded-lg border border-slate-200 p-5">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Ativos</p>
          <p className="text-2xl font-semibold text-green-700 mt-2 font-mono">{ativos}</p>
        </div>
        <div className="bg-white rounded-lg border border-slate-200 p-5">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Inativos</p>
          <p className="text-2xl font-semibold text-slate-400 mt-2 font-mono">{membros.length - ativos}</p>
        </div>
      </div>

      {/* Toast */}
      {sucesso && (
        <div className="bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3 rounded-lg flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-green-500 shrink-0" />
          {sucesso}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <input
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          placeholder="Buscar por nome, subárea ou cargo…"
          className="flex-1 max-w-sm px-3 py-2 rounded-md border border-slate-200 bg-white text-sm text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400/30 focus:border-blue-400"
        />
        <button
          onClick={() => setShowForm((v) => !v)}
          className="shrink-0 text-xs font-medium px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors"
        >
          {showForm ? 'Cancelar' : '+ Cadastrar membro'}
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <form onSubmit={cadastrar} className="bg-white rounded-lg border border-slate-200 p-5 grid grid-cols-2 gap-4">
          <h3 className="col-span-2 text-sm font-semibold text-slate-800">Novo Membro</h3>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Nome completo</label>
            <input
              required
              value={form.nome}
              onChange={(e) => setForm({ ...form, nome: e.target.value })}
              className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30"
              placeholder="Ex: João Silva"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">E-mail institucional</label>
            <input
              required
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30"
              placeholder="joao.silva@procobaja.com"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Subárea</label>
            <select
              value={form.subarea}
              onChange={(e) => setForm({ ...form, subarea: e.target.value })}
              className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-400/30"
            >
              {SUBAREAS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Cargo</label>
            <select
              value={form.cargo}
              onChange={(e) => setForm({ ...form, cargo: e.target.value })}
              className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-400/30"
            >
              {CARGOS.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Data de ingresso</label>
            <input
              required
              type="date"
              value={form.ingresso}
              onChange={(e) => setForm({ ...form, ingresso: e.target.value })}
              className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30"
            />
          </div>
          <div className="col-span-2 flex justify-end gap-2 pt-1">
            <button type="button" onClick={() => setShowForm(false)} className="text-xs px-3 py-1.5 rounded border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors">Cancelar</button>
            <button type="submit" className="text-xs px-4 py-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 transition-colors font-medium">Cadastrar</button>
          </div>
        </form>
      )}

      {/* Table */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-100">
          <p className="text-xs text-slate-400">{filtrados.length} resultado{filtrados.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                <th className="px-5 py-3 text-left">ID</th>
                <th className="px-5 py-3 text-left">Nome</th>
                <th className="px-5 py-3 text-left">E-mail</th>
                <th className="px-5 py-3 text-left">Subárea</th>
                <th className="px-5 py-3 text-left">Cargo</th>
                <th className="px-5 py-3 text-left">Ingresso</th>
                <th className="px-5 py-3 text-left">Status</th>
                <th className="px-5 py-3 text-left"></th>
              </tr>
            </thead>
            <tbody>
              {filtrados.map((m) => (
                <tr key={m.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors">
                  <td className="px-5 py-3 font-mono text-xs text-slate-400">{m.id}</td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-xs font-semibold text-slate-600 shrink-0">
                        {m.nome.split(' ').map((n) => n[0]).join('')}
                      </div>
                      <span className="font-medium text-slate-700">{m.nome}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-slate-400 text-xs">{m.email}</td>
                  <td className="px-5 py-3 text-slate-500 text-xs">{m.subarea}</td>
                  <td className="px-5 py-3 text-slate-500 text-xs">{m.cargo}</td>
                  <td className="px-5 py-3 text-slate-400 text-xs whitespace-nowrap">{m.ingresso}</td>
                  <td className="px-5 py-3">
                    <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLOR[m.status]}`}>{m.status}</span>
                  </td>
                  <td className="px-5 py-3">
                    <button
                      onClick={() => toggleStatus(m.id)}
                      className="text-xs text-slate-400 hover:text-slate-700 transition-colors"
                    >
                      {m.status === 'Ativo' ? 'Desativar' : 'Reativar'}
                    </button>
                  </td>
                </tr>
              ))}
              {filtrados.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-5 py-8 text-center text-sm text-slate-300">Nenhum membro encontrado.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
