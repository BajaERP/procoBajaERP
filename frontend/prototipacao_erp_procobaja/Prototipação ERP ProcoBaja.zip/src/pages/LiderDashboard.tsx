import { useState } from 'react'

const SUBSISTEMA = 'Chassis'

const MEMBROS = [
  { id: 'M001', nome: 'Ana Souza', horasRegistradas: 42, horasMeta: 40, tarefasConcluidas: 8, tarefasPendentes: 2, presencas: 9, totalReunioes: 10 },
  { id: 'M002', nome: 'Thiago Faria', horasRegistradas: 28, horasMeta: 40, tarefasConcluidas: 4, tarefasPendentes: 5, presencas: 6, totalReunioes: 10 },
  { id: 'M003', nome: 'Felipe Rocha', horasRegistradas: 12, horasMeta: 40, tarefasConcluidas: 3, tarefasPendentes: 6, presencas: 4, totalReunioes: 10 },
]

type TaskStatus = 'a-fazer' | 'em-andamento' | 'concluido'

interface Tarefa {
  id: string
  titulo: string
  membroId: string
  prioridade: 'Alta' | 'Média' | 'Baixa'
  status: TaskStatus
}

const TAREFAS_INICIAIS: Tarefa[] = [
  { id: 'k1', titulo: 'Modelar suporte de suspensão', membroId: 'M001', prioridade: 'Alta', status: 'a-fazer' },
  { id: 'k2', titulo: 'Soldagem do quadro principal', membroId: 'M002', prioridade: 'Alta', status: 'em-andamento' },
  { id: 'k3', titulo: 'Revisão do projeto 3D', membroId: 'M001', prioridade: 'Média', status: 'concluido' },
  { id: 'k4', titulo: 'Atualizar planilha de peças', membroId: 'M003', prioridade: 'Baixa', status: 'a-fazer' },
  { id: 'k5', titulo: 'Teste de resistência do chassi', membroId: 'M002', prioridade: 'Alta', status: 'a-fazer' },
]

interface Sprint {
  id: string
  nome: string
  inicio: string
  fim: string
  progresso: number
  status: 'Ativo' | 'Concluído' | 'Planejado'
}

const SPRINTS_INICIAIS: Sprint[] = [
  { id: 'S-04', nome: 'Sprint 4 – Integração', inicio: '16 set 2026', fim: '30 set 2026', progresso: 62, status: 'Ativo' },
  { id: 'S-03', nome: 'Sprint 3 – Montagem', inicio: '01 set 2026', fim: '15 set 2026', progresso: 100, status: 'Concluído' },
  { id: 'S-02', nome: 'Sprint 2 – Prototipagem', inicio: '15 ago 2026', fim: '31 ago 2026', progresso: 100, status: 'Concluído' },
]

const PRIORIDADE_COLOR: Record<string, string> = {
  Alta: 'bg-red-50 text-red-600',
  Média: 'bg-amber-50 text-amber-600',
  Baixa: 'bg-slate-100 text-slate-500',
}

const COLUNAS: { id: TaskStatus; label: string }[] = [
  { id: 'a-fazer', label: 'A Fazer' },
  { id: 'em-andamento', label: 'Em Andamento' },
  { id: 'concluido', label: 'Concluído' },
]

export function LiderDashboard() {
  const [tarefas, setTarefas] = useState(TAREFAS_INICIAIS)
  const [sprints, setSprints] = useState(SPRINTS_INICIAIS)
  const [showSprintForm, setShowSprintForm] = useState(false)
  const [showTaskForm, setShowTaskForm] = useState(false)
  const [novoSprint, setNovoSprint] = useState({ nome: '', inicio: '', fim: '' })
  const [novaTarefa, setNovaTarefa] = useState({ titulo: '', membroId: 'M001', prioridade: 'Média' as Tarefa['prioridade'] })

  function moverTarefa(id: string, status: TaskStatus) {
    setTarefas((prev) => prev.map((t) => t.id === id ? { ...t, status } : t))
  }

  function criarSprint(e: React.FormEvent) {
    e.preventDefault()
    setSprints((prev) => [{ id: `S-0${prev.length + 2}`, ...novoSprint, progresso: 0, status: 'Planejado' as const }, ...prev])
    setNovoSprint({ nome: '', inicio: '', fim: '' })
    setShowSprintForm(false)
  }

  function adicionarTarefa(e: React.FormEvent) {
    e.preventDefault()
    setTarefas((prev) => [{ id: `k${Date.now()}`, ...novaTarefa, status: 'a-fazer' }, ...prev])
    setNovaTarefa({ titulo: '', membroId: 'M001', prioridade: 'Média' })
    setShowTaskForm(false)
  }

  function nomeMembro(id: string) {
    return MEMBROS.find((m) => m.id === id)?.nome ?? id
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-semibold text-slate-800">Subsistema — {SUBSISTEMA}</h2>
          <p className="text-xs text-slate-400 mt-0.5">Sprint atual: Sprint 4 · Set 2026</p>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Membros', value: MEMBROS.length },
          { label: 'Tarefas Abertas', value: tarefas.filter((t) => t.status !== 'concluido').length },
          { label: 'Concluídas', value: tarefas.filter((t) => t.status === 'concluido').length },
          { label: 'Progresso Sprint', value: '62%' },
        ].map((k) => (
          <div key={k.label} className="bg-white rounded-lg border border-slate-200 p-5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{k.label}</p>
            <p className="text-2xl font-semibold text-slate-900 mt-2 font-mono">{k.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Kanban */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-800">Kanban — {SUBSISTEMA}</h3>
            <button onClick={() => setShowTaskForm((v) => !v)} className="text-xs font-medium px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors">
              {showTaskForm ? 'Cancelar' : '+ Nova tarefa'}
            </button>
          </div>

          {showTaskForm && (
            <form onSubmit={adicionarTarefa} className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap gap-3 items-end">
              <div className="flex-1 min-w-40">
                <label className="block text-xs font-medium text-slate-600 mb-1">Título</label>
                <input required value={novaTarefa.titulo} onChange={(e) => setNovaTarefa({ ...novaTarefa, titulo: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" placeholder="Descreva a tarefa" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Membro</label>
                <select value={novaTarefa.membroId} onChange={(e) => setNovaTarefa({ ...novaTarefa, membroId: e.target.value })} className="px-3 py-1.5 rounded border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-400/30">
                  {MEMBROS.map((m) => <option key={m.id} value={m.id}>{m.nome}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Prioridade</label>
                <select value={novaTarefa.prioridade} onChange={(e) => setNovaTarefa({ ...novaTarefa, prioridade: e.target.value as Tarefa['prioridade'] })} className="px-3 py-1.5 rounded border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-400/30">
                  <option>Alta</option><option>Média</option><option>Baixa</option>
                </select>
              </div>
              <button type="submit" className="text-xs px-4 py-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 font-medium h-[30px]">Adicionar</button>
            </form>
          )}

          <div className="grid grid-cols-3 gap-3">
            {COLUNAS.map((col) => {
              const cards = tarefas.filter((t) => t.status === col.id)
              return (
                <div key={col.id} className="bg-white rounded-lg border border-slate-200 overflow-hidden">
                  <div className="px-3 py-2.5 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">{col.label}</span>
                    <span className="text-xs font-mono text-slate-400">{cards.length}</span>
                  </div>
                  <div className="p-2 space-y-2 min-h-[100px]">
                    {cards.map((t) => (
                      <div key={t.id} className="bg-slate-50 rounded border border-slate-100 p-2.5 group">
                        <p className="text-xs font-semibold text-slate-700 leading-snug mb-1">{t.titulo}</p>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] text-slate-400">{nomeMembro(t.membroId)}</span>
                          <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${PRIORIDADE_COLOR[t.prioridade]}`}>{t.prioridade}</span>
                        </div>
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {COLUNAS.filter((c) => c.id !== col.id).map((dest) => (
                            <button key={dest.id} onClick={() => moverTarefa(t.id, dest.id)} className="text-[10px] px-1.5 py-0.5 rounded bg-white border border-slate-200 text-slate-400 hover:text-blue-600 hover:border-blue-300 transition-colors truncate max-w-[80px]">
                              → {dest.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                    {cards.length === 0 && <p className="text-xs text-slate-300 text-center py-3">Vazio</p>}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Coluna direita */}
        <div className="space-y-4">
          {/* Sprints */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-slate-800">Sprints</h3>
              <button onClick={() => setShowSprintForm((v) => !v)} className="text-xs font-medium px-2.5 py-1 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors">+ Novo</button>
            </div>
            {showSprintForm && (
              <form onSubmit={criarSprint} className="bg-white border border-slate-200 rounded-lg p-4 space-y-3 mb-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Nome</label>
                  <input required value={novoSprint.nome} onChange={(e) => setNovoSprint({ ...novoSprint, nome: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" placeholder="Sprint 5 – …" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div><label className="block text-xs font-medium text-slate-600 mb-1">Início</label><input required type="date" value={novoSprint.inicio} onChange={(e) => setNovoSprint({ ...novoSprint, inicio: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" /></div>
                  <div><label className="block text-xs font-medium text-slate-600 mb-1">Fim</label><input required type="date" value={novoSprint.fim} onChange={(e) => setNovoSprint({ ...novoSprint, fim: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" /></div>
                </div>
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => setShowSprintForm(false)} className="text-xs px-3 py-1.5 rounded border border-slate-200 text-slate-600 hover:bg-slate-50">Cancelar</button>
                  <button type="submit" className="text-xs px-4 py-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 font-medium">Criar</button>
                </div>
              </form>
            )}
            <div className="space-y-2">
              {sprints.map((s) => (
                <div key={s.id} className="bg-white rounded-lg border border-slate-200 p-3.5">
                  <div className="flex items-start justify-between mb-1.5">
                    <p className="text-xs font-semibold text-slate-700">{s.nome}</p>
                    <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${s.status === 'Ativo' ? 'bg-blue-50 text-blue-600' : s.status === 'Planejado' ? 'bg-amber-50 text-amber-600' : 'bg-slate-100 text-slate-500'}`}>{s.status}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mb-2">{s.inicio} → {s.fim}</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-blue-500" style={{ width: `${s.progresso}%` }} />
                    </div>
                    <span className="text-[11px] font-mono text-slate-400">{s.progresso}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Membros do subsistema */}
          <div>
            <h3 className="text-sm font-semibold text-slate-800 mb-3">Meus Membros</h3>
            <div className="space-y-2">
              {MEMBROS.map((m) => {
                const pct = Math.round((m.presencas / m.totalReunioes) * 100)
                return (
                  <div key={m.id} className="bg-white rounded-lg border border-slate-200 p-3.5">
                    <div className="flex items-center gap-2.5 mb-2">
                      <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-xs font-semibold text-slate-600 shrink-0">
                        {m.nome.split(' ').map((n) => n[0]).join('')}
                      </div>
                      <p className="text-xs font-medium text-slate-700">{m.nome}</p>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div>
                        <p className="text-[10px] text-slate-400">Presença</p>
                        <p className="text-xs font-mono font-semibold text-slate-700">{pct}%</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400">Horas</p>
                        <p className="text-xs font-mono font-semibold text-slate-700">{m.horasRegistradas}h</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400">Tarefas ✓</p>
                        <p className="text-xs font-mono font-semibold text-slate-700">{m.tarefasConcluidas}</p>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
