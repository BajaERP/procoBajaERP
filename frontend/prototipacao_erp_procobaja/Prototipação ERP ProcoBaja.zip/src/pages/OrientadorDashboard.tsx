// Orientador: read-only overview of the whole project

const SUBSISTEMAS = [
  { nome: 'Chassis', lider: 'Thiago Alves', membros: 3, progresso: 72, status: 'No prazo' },
  { nome: 'Motor', lider: '—', membros: 2, progresso: 54, status: 'Atenção' },
  { nome: 'Dinâmica', lider: 'Carla Mendes', membros: 2, progresso: 91, status: 'No prazo' },
  { nome: 'TI', lider: '—', membros: 1, progresso: 40, status: 'Atenção' },
  { nome: 'Elétrica', lider: '—', membros: 0, progresso: 0, status: 'Sem início' },
]

const MEMBROS_OVERVIEW = [
  { nome: 'Ana Souza', subarea: 'Chassis', presenca: 90, horas: 42, status: 'Ativo' },
  { nome: 'Bruno Lima', subarea: 'Motor', presenca: 70, horas: 28, status: 'Atenção' },
  { nome: 'Carla Mendes', subarea: 'Dinâmica', presenca: 100, horas: 55, status: 'Ativo' },
  { nome: 'Diego Costa', subarea: 'TI', presenca: 80, horas: 35, status: 'Ativo' },
  { nome: 'Felipe Rocha', subarea: 'Chassis', presenca: 40, horas: 12, status: 'Crítico' },
  { nome: 'Gabriela Nunes', subarea: 'Motor', presenca: 90, horas: 38, status: 'Ativo' },
]

const STATUS_COLOR: Record<string, string> = {
  'No prazo': 'bg-green-50 text-green-700',
  'Atenção': 'bg-amber-50 text-amber-600',
  'Sem início': 'bg-slate-100 text-slate-400',
  'Ativo': 'bg-green-50 text-green-700',
  'Crítico': 'bg-red-50 text-red-600',
}

const SPRINTS_RECENTES = [
  { id: 'S-04', nome: 'Sprint 4 – Integração', periodo: '16–30 set 2026', progresso: 62, status: 'Ativo' },
  { id: 'S-03', nome: 'Sprint 3 – Montagem', periodo: '01–15 set 2026', progresso: 100, status: 'Concluído' },
  { id: 'S-02', nome: 'Sprint 2 – Prototipagem', periodo: '15–31 ago 2026', progresso: 100, status: 'Concluído' },
]

const FINANCEIRO_RESUMO = {
  receitas: 'R$ 26.000',
  despesas: 'R$ 10.360',
  saldo: 'R$ 15.640',
  patrocinios: 7,
}

export function OrientadorDashboard() {
  const mediaPresenca = Math.round(MEMBROS_OVERVIEW.reduce((a, m) => a + m.presenca, 0) / MEMBROS_OVERVIEW.length)
  const totalHoras = MEMBROS_OVERVIEW.reduce((a, m) => a + m.horas, 0)

  return (
    <div className="p-6 space-y-6">
      {/* Aviso read-only */}
      <div className="bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 flex items-center gap-2.5">
        <span className="text-[11px] font-bold px-1.5 py-0.5 rounded bg-slate-200 text-slate-600 tracking-widest">LEITURA</span>
        <p className="text-xs text-slate-500">Você está no modo Orientador. Todas as informações são somente para consulta.</p>
      </div>

      {/* KPIs gerais */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Membros Ativos', value: '6' },
          { label: 'Média de Presença', value: `${mediaPresenca}%` },
          { label: 'Total de Horas', value: `${totalHoras}h` },
          { label: 'Sprint Atual', value: 'Sprint 4' },
        ].map((k) => (
          <div key={k.label} className="bg-white rounded-lg border border-slate-200 p-5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{k.label}</p>
            <p className="text-2xl font-semibold text-slate-900 mt-2 font-mono">{k.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Progresso por subsistema */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-sm font-semibold text-slate-800">Progresso por Subsistema</h2>
          <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                  <th className="px-5 py-3 text-left">Subsistema</th>
                  <th className="px-5 py-3 text-left">Líder</th>
                  <th className="px-5 py-3 text-center">Membros</th>
                  <th className="px-5 py-3 text-left">Progresso</th>
                  <th className="px-5 py-3 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {SUBSISTEMAS.map((s) => (
                  <tr key={s.nome} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="px-5 py-3 font-medium text-slate-700 text-xs">{s.nome}</td>
                    <td className="px-5 py-3 text-xs text-slate-400">{s.lider}</td>
                    <td className="px-5 py-3 text-center text-xs font-mono text-slate-600">{s.membros}</td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full rounded-full bg-blue-500" style={{ width: `${s.progresso}%` }} />
                        </div>
                        <span className="text-xs font-mono text-slate-500">{s.progresso}%</span>
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <span className={`inline-flex px-2 py-0.5 rounded text-[11px] font-medium ${STATUS_COLOR[s.status]}`}>{s.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Membros */}
          <h2 className="text-sm font-semibold text-slate-800 pt-2">Equipe</h2>
          <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                  <th className="px-5 py-3 text-left">Membro</th>
                  <th className="px-5 py-3 text-left">Subárea</th>
                  <th className="px-5 py-3 text-center">Presença</th>
                  <th className="px-5 py-3 text-center">Horas</th>
                  <th className="px-5 py-3 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {MEMBROS_OVERVIEW.map((m) => (
                  <tr key={m.nome} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-[10px] font-semibold text-slate-600 shrink-0">
                          {m.nome.split(' ').map((n) => n[0]).join('')}
                        </div>
                        <span className="font-medium text-slate-700 text-xs">{m.nome}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3 text-xs text-slate-400">{m.subarea}</td>
                    <td className="px-5 py-3 text-center text-xs font-mono text-slate-600">{m.presenca}%</td>
                    <td className="px-5 py-3 text-center text-xs font-mono text-slate-600">{m.horas}h</td>
                    <td className="px-5 py-3">
                      <span className={`inline-flex px-2 py-0.5 rounded text-[11px] font-medium ${STATUS_COLOR[m.status]}`}>{m.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Coluna direita */}
        <div className="space-y-4">
          {/* Resumo financeiro */}
          <div className="bg-white rounded-lg border border-slate-200 p-5">
            <h3 className="text-sm font-semibold text-slate-800 mb-4">Resumo Financeiro</h3>
            <div className="space-y-2.5">
              <div className="flex justify-between text-sm">
                <span className="flex items-center gap-2 text-slate-600"><span className="w-2 h-2 rounded-full bg-green-500" />Receitas</span>
                <span className="font-mono font-semibold text-green-700">{FINANCEIRO_RESUMO.receitas}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="flex items-center gap-2 text-slate-600"><span className="w-2 h-2 rounded-full bg-red-400" />Despesas</span>
                <span className="font-mono font-semibold text-red-600">{FINANCEIRO_RESUMO.despesas}</span>
              </div>
              <div className="border-t border-slate-100 pt-2.5 flex justify-between text-sm font-semibold">
                <span className="text-slate-700">Saldo</span>
                <span className="font-mono text-slate-900">{FINANCEIRO_RESUMO.saldo}</span>
              </div>
              <div className="flex justify-between text-xs text-slate-400 pt-1">
                <span>Patrocínios ativos</span>
                <span className="font-mono">{FINANCEIRO_RESUMO.patrocinios}</span>
              </div>
            </div>
          </div>

          {/* Sprints */}
          <div className="bg-white rounded-lg border border-slate-200 p-5">
            <h3 className="text-sm font-semibold text-slate-800 mb-4">Sprints</h3>
            <div className="space-y-3">
              {SPRINTS_RECENTES.map((s) => (
                <div key={s.id}>
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-medium text-slate-700">{s.nome}</p>
                    <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${s.status === 'Ativo' ? 'bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-400'}`}>{s.status}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mb-1">{s.periodo}</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-blue-500" style={{ width: `${s.progresso}%` }} />
                    </div>
                    <span className="text-[11px] font-mono text-slate-400">{s.progresso}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
