import { useState } from 'react'

interface Membro {
  id: string
  nome: string
  subarea: string
  presencas: number
  totalReunioes: number
  horasRegistradas: number
  horasMeta: number
  status: 'Ativo' | 'Atenção' | 'Crítico'
  observacoes: string[]
}

const MEMBROS_INICIAIS: Membro[] = [
  { id: 'M001', nome: 'Ana Souza', subarea: 'Chassis', presencas: 9, totalReunioes: 10, horasRegistradas: 42, horasMeta: 40, status: 'Ativo', observacoes: ['Excelente participação nas reuniões.'] },
  { id: 'M002', nome: 'Bruno Lima', subarea: 'Motor', presencas: 7, totalReunioes: 10, horasRegistradas: 28, horasMeta: 40, status: 'Atenção', observacoes: ['Presença abaixo do esperado em setembro.'] },
  { id: 'M003', nome: 'Carla Mendes', subarea: 'Dinâmica', presencas: 10, totalReunioes: 10, horasRegistradas: 55, horasMeta: 40, status: 'Ativo', observacoes: [] },
  { id: 'M004', nome: 'Diego Costa', subarea: 'TI', presencas: 8, totalReunioes: 10, horasRegistradas: 35, horasMeta: 40, status: 'Ativo', observacoes: [] },
  { id: 'M005', nome: 'Felipe Rocha', subarea: 'Chassis', presencas: 4, totalReunioes: 10, horasRegistradas: 12, horasMeta: 40, status: 'Crítico', observacoes: ['Múltiplas faltas sem justificativa.', 'Contato realizado em 18/09/2026.'] },
  { id: 'M006', nome: 'Gabriela Nunes', subarea: 'Motor', presencas: 9, totalReunioes: 10, horasRegistradas: 38, horasMeta: 40, status: 'Ativo', observacoes: [] },
]

interface Reuniao {
  titulo: string
  data: string
  hora: string
  tipo: string
  presentes: string[]
}

const REUNIOES: Reuniao[] = [
  { titulo: 'Reunião Semanal Geral', data: 'Ter, 23 set 2026', hora: '19h00', tipo: 'Obrigatória', presentes: ['M001', 'M002', 'M003', 'M004', 'M006'] },
  { titulo: 'Review Sprint 4', data: 'Sex, 20 set 2026', hora: '18h30', tipo: 'Obrigatória', presentes: ['M001', 'M003', 'M004', 'M005', 'M006'] },
  { titulo: 'Workshop Chassis', data: 'Qua, 18 set 2026', hora: '18h00', tipo: 'Opcional', presentes: ['M001', 'M003'] },
]

const STATUS_COLOR: Record<string, string> = {
  Ativo: 'bg-green-50 text-green-700',
  Atenção: 'bg-amber-50 text-amber-700',
  Crítico: 'bg-red-50 text-red-600',
}

export function GestorDashboard() {
  const [membros, setMembros] = useState(MEMBROS_INICIAIS)
  const [membroSelecionado, setMembroSelecionado] = useState<string | null>(null)
  const [novaObs, setNovaObs] = useState('')
  const [abaAtiva, setAbaAtiva] = useState<'membros' | 'presencas' | 'reunioes'>('membros')

  const membro = membros.find((m) => m.id === membroSelecionado)

  function adicionarObservacao(id: string) {
    if (!novaObs.trim()) return
    setMembros((prev) => prev.map((m) => m.id === id ? { ...m, observacoes: [...m.observacoes, novaObs.trim()] } : m))
    setNovaObs('')
  }

  const criticos = membros.filter((m) => m.status === 'Crítico').length
  const atencao = membros.filter((m) => m.status === 'Atenção').length
  const mediaPresenca = Math.round(membros.reduce((acc, m) => acc + (m.presencas / m.totalReunioes) * 100, 0) / membros.length)

  return (
    <div className="p-6 space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Membros Ativos', value: membros.length, cor: 'text-slate-900' },
          { label: 'Média de Presença', value: `${mediaPresenca}%`, cor: 'text-blue-700' },
          { label: 'Em Atenção', value: atencao, cor: 'text-amber-600' },
          { label: 'Situação Crítica', value: criticos, cor: 'text-red-600' },
        ].map((k) => (
          <div key={k.label} className="bg-white rounded-lg border border-slate-200 p-5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{k.label}</p>
            <p className={`text-2xl font-semibold mt-2 font-mono ${k.cor}`}>{k.value}</p>
          </div>
        ))}
      </div>

      {/* Abas */}
      <div className="flex gap-1 border-b border-slate-200">
        {([['membros', 'Membros'], ['presencas', 'Presenças'], ['reunioes', 'Reuniões']] as const).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setAbaAtiva(id)}
            className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${
              abaAtiva === id ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Aba Membros */}
      {abaAtiva === 'membros' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white rounded-lg border border-slate-200 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                  <th className="px-5 py-3 text-left">Membro</th>
                  <th className="px-5 py-3 text-left">Subárea</th>
                  <th className="px-5 py-3 text-center">Presença</th>
                  <th className="px-5 py-3 text-center">Horas</th>
                  <th className="px-5 py-3 text-left">Status</th>
                  <th className="px-5 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {membros.map((m) => {
                  const pctPresenca = Math.round((m.presencas / m.totalReunioes) * 100)
                  return (
                    <tr key={m.id} className={`border-b border-slate-50 hover:bg-slate-50/60 transition-colors cursor-pointer ${membroSelecionado === m.id ? 'bg-blue-50/40' : ''}`} onClick={() => setMembroSelecionado(membroSelecionado === m.id ? null : m.id)}>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-xs font-semibold text-slate-600 shrink-0">
                            {m.nome.split(' ').map((n) => n[0]).join('')}
                          </div>
                          <span className="font-medium text-slate-700 text-xs">{m.nome}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3 text-xs text-slate-400">{m.subarea}</td>
                      <td className="px-5 py-3 text-center text-xs font-mono text-slate-600">{pctPresenca}%</td>
                      <td className="px-5 py-3 text-center text-xs font-mono text-slate-600">{m.horasRegistradas}h</td>
                      <td className="px-5 py-3">
                        <span className={`inline-flex px-2 py-0.5 rounded text-[11px] font-medium ${STATUS_COLOR[m.status]}`}>{m.status}</span>
                      </td>
                      <td className="px-5 py-3 text-xs text-blue-500">{membroSelecionado === m.id ? '▲' : '▼'}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {/* Painel lateral de observações */}
          <div className="bg-white rounded-lg border border-slate-200 p-5 flex flex-col gap-3">
            <h3 className="text-sm font-semibold text-slate-800">
              {membro ? `Observações — ${membro.nome}` : 'Selecione um membro'}
            </h3>
            {membro ? (
              <>
                <div className="flex-1 space-y-2 min-h-[120px]">
                  {membro.observacoes.length === 0 && (
                    <p className="text-xs text-slate-300">Nenhuma observação registrada.</p>
                  )}
                  {membro.observacoes.map((obs, i) => (
                    <div key={i} className="bg-slate-50 rounded p-2.5">
                      <p className="text-xs text-slate-600 leading-snug">{obs}</p>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2 pt-2 border-t border-slate-100">
                  <input
                    value={novaObs}
                    onChange={(e) => setNovaObs(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && adicionarObservacao(membro.id)}
                    placeholder="Nova observação…"
                    className="flex-1 px-3 py-1.5 rounded border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-blue-400/30"
                  />
                  <button onClick={() => adicionarObservacao(membro.id)} className="text-xs px-3 py-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 transition-colors">+</button>
                </div>
              </>
            ) : (
              <p className="text-xs text-slate-300">Clique em um membro para ver e registrar observações.</p>
            )}
          </div>
        </div>
      )}

      {/* Aba Presenças */}
      {abaAtiva === 'presencas' && (
        <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                <th className="px-5 py-3 text-left">Membro</th>
                <th className="px-5 py-3 text-left">Subárea</th>
                <th className="px-5 py-3 text-center">Presenças</th>
                <th className="px-5 py-3 text-center">Reuniões</th>
                <th className="px-5 py-3 text-left">Taxa</th>
                <th className="px-5 py-3 text-left">Status</th>
              </tr>
            </thead>
            <tbody>
              {membros.map((m) => {
                const pct = Math.round((m.presencas / m.totalReunioes) * 100)
                return (
                  <tr key={m.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="px-5 py-3 font-medium text-slate-700 text-xs">{m.nome}</td>
                    <td className="px-5 py-3 text-xs text-slate-400">{m.subarea}</td>
                    <td className="px-5 py-3 text-center font-mono text-xs text-slate-600">{m.presencas}</td>
                    <td className="px-5 py-3 text-center font-mono text-xs text-slate-400">{m.totalReunioes}</td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: pct >= 80 ? '#22c55e' : pct >= 60 ? '#f59e0b' : '#ef4444' }} />
                        </div>
                        <span className="text-xs font-mono text-slate-500">{pct}%</span>
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <span className={`inline-flex px-2 py-0.5 rounded text-[11px] font-medium ${STATUS_COLOR[m.status]}`}>{m.status}</span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Aba Reuniões */}
      {abaAtiva === 'reunioes' && (
        <div className="space-y-4">
          {REUNIOES.map((r, i) => (
            <div key={i} className="bg-white rounded-lg border border-slate-200 p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-sm font-semibold text-slate-800">{r.titulo}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{r.data} · {r.hora}</p>
                </div>
                <span className={`text-[11px] font-medium px-2 py-0.5 rounded ${r.tipo === 'Obrigatória' ? 'bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-500'}`}>{r.tipo}</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {membros.map((m) => {
                  const presente = r.presentes.includes(m.id)
                  return (
                    <span key={m.id} className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${presente ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-500'}`}>
                      {m.nome.split(' ')[0]} {presente ? '✓' : '✗'}
                    </span>
                  )
                })}
              </div>
              <p className="text-[11px] text-slate-400 mt-2">{r.presentes.length}/{membros.length} presentes</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
