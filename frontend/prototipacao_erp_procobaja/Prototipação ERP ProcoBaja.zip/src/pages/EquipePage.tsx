// Gestão de Equipe e Subsistemas
// Roles: Capitão (full), Gestor (full), Orientador (read-only)

type Role = string

const SUBSISTEMAS = [
  { id: 'SS01', nome: 'Chassis', lider: 'Thiago Alves', membros: 3, status: 'Ativo' },
  { id: 'SS02', nome: 'Motor', lider: '—', membros: 2, status: 'Sem líder' },
  { id: 'SS03', nome: 'Dinâmica', lider: 'Carla Mendes', membros: 2, status: 'Ativo' },
  { id: 'SS04', nome: 'TI', lider: '—', membros: 1, status: 'Sem líder' },
  { id: 'SS05', nome: 'Elétrica', lider: '—', membros: 0, status: 'Sem membros' },
]

const USUARIOS = [
  { id: 'U001', nome: 'Rafael Torres', cargo: 'Capitão', subsistema: 'Gestão', status: 'Ativo' },
  { id: 'U002', nome: 'Eduarda Pires', cargo: 'Gestor', subsistema: 'Gestão', status: 'Ativo' },
  { id: 'U003', nome: 'Marcos Henrique', cargo: 'Financeiro', subsistema: 'Financeiro', status: 'Ativo' },
  { id: 'U004', nome: 'Carla Mendes', cargo: 'Líder', subsistema: 'Dinâmica', status: 'Ativo' },
  { id: 'U005', nome: 'Thiago Alves', cargo: 'Líder', subsistema: 'Chassis', status: 'Ativo' },
  { id: 'U006', nome: 'Ana Souza', cargo: 'Membro', subsistema: 'Chassis', status: 'Ativo' },
  { id: 'U007', nome: 'Bruno Lima', cargo: 'Membro', subsistema: 'Motor', status: 'Ativo' },
  { id: 'U008', nome: 'Felipe Rocha', cargo: 'Membro', subsistema: 'Chassis', status: 'Inativo' },
  { id: 'U009', nome: 'Prof. Antônio Cruz', cargo: 'Orientador', subsistema: '—', status: 'Ativo' },
]

const STATUS_SS: Record<string, string> = {
  'Ativo': 'bg-green-50 text-green-700',
  'Sem líder': 'bg-amber-50 text-amber-700',
  'Sem membros': 'bg-slate-100 text-slate-400',
}

const CARGO_COLOR: Record<string, string> = {
  Capitão: 'bg-[#0f1729] text-white',
  Gestor: 'bg-violet-50 text-violet-700',
  Financeiro: 'bg-blue-50 text-blue-700',
  Líder: 'bg-indigo-50 text-indigo-700',
  Membro: 'bg-slate-100 text-slate-600',
  Orientador: 'bg-emerald-50 text-emerald-700',
}

interface Props { role?: Role }

export function EquipePage({ role }: Props) {
  const readOnly = role === 'orientador'

  return (
    <div className="p-6 space-y-6">
      {readOnly && <ReadOnlyBanner />}

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Integrantes', value: USUARIOS.length },
          { label: 'Ativos', value: USUARIOS.filter((u) => u.status === 'Ativo').length },
          { label: 'Subsistemas', value: SUBSISTEMAS.length },
          { label: 'Sem Líder', value: SUBSISTEMAS.filter((s) => s.lider === '—').length },
        ].map((k) => (
          <div key={k.label} className="bg-white rounded-lg border border-slate-200 p-5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{k.label}</p>
            <p className="text-2xl font-semibold text-slate-900 mt-2 font-mono">{k.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Usuários */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-slate-800">Integrantes</h2>
            {!readOnly && (
              <ScreenPlaceholderAction label="+ Cadastrar integrante" />
            )}
          </div>
          <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                  <th className="px-5 py-3 text-left">Nome</th>
                  <th className="px-5 py-3 text-left">Cargo</th>
                  <th className="px-5 py-3 text-left">Subsistema</th>
                  <th className="px-5 py-3 text-left">Status</th>
                  {!readOnly && <th className="px-5 py-3" />}
                </tr>
              </thead>
              <tbody>
                {USUARIOS.map((u) => (
                  <tr key={u.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-[10px] font-semibold text-slate-600 shrink-0">
                          {u.nome.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                        </div>
                        <span className="text-xs font-medium text-slate-700">{u.nome}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <span className={`inline-flex px-2 py-0.5 rounded text-[11px] font-medium ${CARGO_COLOR[u.cargo] ?? 'bg-slate-100 text-slate-500'}`}>{u.cargo}</span>
                    </td>
                    <td className="px-5 py-3 text-xs text-slate-400">{u.subsistema}</td>
                    <td className="px-5 py-3">
                      <span className={`inline-flex px-2 py-0.5 rounded text-[11px] font-medium ${u.status === 'Ativo' ? 'bg-green-50 text-green-700' : 'bg-slate-100 text-slate-400'}`}>{u.status}</span>
                    </td>
                    {!readOnly && (
                      <td className="px-5 py-3 text-xs text-blue-500 cursor-pointer hover:text-blue-700">Editar</td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Subsistemas */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-slate-800">Subsistemas</h2>
            {!readOnly && <ScreenPlaceholderAction label="+ Novo" />}
          </div>
          <div className="space-y-2">
            {SUBSISTEMAS.map((s) => (
              <div key={s.id} className="bg-white rounded-lg border border-slate-200 p-4">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-semibold text-slate-800">{s.nome}</p>
                  <span className={`text-[11px] font-medium px-1.5 py-0.5 rounded ${STATUS_SS[s.status]}`}>{s.status}</span>
                </div>
                <p className="text-[11px] text-slate-400">Líder: {s.lider}</p>
                <p className="text-[11px] text-slate-400">{s.membros} membro{s.membros !== 1 ? 's' : ''}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <ScreenNote>
        Esta tela incluirá: cadastro e edição de integrantes, atribuição de cargos e permissões por subsistema, definição de líderes e gestão completa da estrutura da equipe.
      </ScreenNote>
    </div>
  )
}

// ── Shared helpers ────────────────────────────────────────────────────

export function ReadOnlyBanner() {
  return (
    <div className="bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 flex items-center gap-2.5">
      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-200 text-slate-600 tracking-widest shrink-0">LEITURA</span>
      <p className="text-xs text-slate-500">Modo Orientador — somente consulta.</p>
    </div>
  )
}

export function ScreenNote({ children }: { children: React.ReactNode }) {
  return (
    <div className="border border-dashed border-slate-200 rounded-lg px-5 py-4">
      <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-widest mb-1">Tela em desenvolvimento</p>
      <p className="text-xs text-slate-400 leading-relaxed">{children}</p>
    </div>
  )
}

function ScreenPlaceholderAction({ label }: { label: string }) {
  return (
    <button className="text-xs font-medium px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors opacity-50 cursor-not-allowed" disabled title="Em desenvolvimento">
      {label}
    </button>
  )
}
