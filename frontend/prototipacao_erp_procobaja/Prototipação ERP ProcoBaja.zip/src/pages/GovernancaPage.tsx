// Gestão de Governança
// Roles: Capitão (full edit), Gestor (propose changes), Orientador (read-only), others (read-only)

type Role = string
import { ReadOnlyBanner, ScreenNote } from './EquipePage'

const DOCUMENTOS_GOV = [
  { id: 'G001', titulo: 'Regimento Interno v3.2', tipo: 'Regimento', versao: '3.2', vigente: true, atualizado: '01 set 2026', autor: 'Rafael Torres', descricao: 'Documento principal que rege as relações, direitos e deveres dos membros da equipe.' },
  { id: 'G002', titulo: 'Política de Participação e Frequência', tipo: 'Política', versao: '2.0', vigente: true, atualizado: '01 set 2026', autor: 'Eduarda Pires', descricao: 'Define critérios mínimos de presença, carga horária e advertências.' },
  { id: 'G003', titulo: 'Normas de Uso da Oficina', tipo: 'Norma', versao: '1.4', vigente: true, atualizado: '15 ago 2026', autor: 'Rafael Torres', descricao: 'Regras de segurança e uso do espaço físico da equipe.' },
  { id: 'G004', titulo: 'Código de Ética', tipo: 'Diretriz', versao: '1.0', vigente: true, atualizado: '01 jan 2026', autor: 'Prof. Antônio Cruz', descricao: 'Princípios éticos que orientam a conduta de todos os integrantes.' },
]

const HISTORICO = [
  { id: 'H001', doc: 'Regimento Interno', versao: '3.2', data: '01 set 2026', autor: 'Rafael Torres', descricao: 'Atualização da seção 4 (Cargos) e adição do cargo de Financeiro.' },
  { id: 'H002', doc: 'Política de Participação', versao: '2.0', data: '01 set 2026', autor: 'Eduarda Pires', descricao: 'Revisão completa dos critérios de frequência mínima (de 70% para 75%).' },
  { id: 'H003', doc: 'Normas de Uso da Oficina', versao: '1.4', data: '15 ago 2026', autor: 'Rafael Torres', descricao: 'Inclusão de normas para uso de ferramentas de corte.' },
]

const TIPO_COLOR: Record<string, string> = {
  Regimento: 'bg-[#0f1729] text-white',
  Política: 'bg-blue-50 text-blue-700',
  Norma: 'bg-amber-50 text-amber-700',
  Diretriz: 'bg-violet-50 text-violet-700',
}

interface Props { role?: Role }

export function GovernancaPage({ role }: Props) {
  const canEdit = role === 'capitao'
  const canPropose = role === 'gestor'
  const isReadOnly = role === 'orientador' || role === 'financeiro' || role === 'lider' || role === 'membro'

  return (
    <div className="p-6 space-y-6">
      {isReadOnly && !canEdit && !canPropose && <ReadOnlyBanner />}
      {canPropose && (
        <div className="bg-violet-50 border border-violet-200 rounded-lg px-4 py-2.5 flex items-center gap-2.5">
          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-violet-200 text-violet-700 tracking-widest shrink-0">GESTOR</span>
          <p className="text-xs text-violet-700">Você pode propor alterações. Aprovação final é do Capitão.</p>
        </div>
      )}

      {/* Documentos vigentes */}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-slate-800">Documentos Vigentes</h2>
        {canEdit && (
          <button className="text-xs font-medium px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors" disabled>
            + Novo documento
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {DOCUMENTOS_GOV.map((d) => (
          <div key={d.id} className="bg-white rounded-lg border border-slate-200 p-5">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <p className="text-sm font-semibold text-slate-800">{d.titulo}</p>
                <p className="text-xs text-slate-400 mt-0.5">Versão {d.versao} · Atualizado em {d.atualizado}</p>
              </div>
              <span className={`text-[11px] font-medium px-2 py-0.5 rounded shrink-0 ${TIPO_COLOR[d.tipo]}`}>{d.tipo}</span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed mb-3">{d.descricao}</p>
            <div className="flex items-center gap-2">
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-green-50 text-green-600 font-medium">Vigente</span>
              <span className="text-[11px] text-slate-400">por {d.autor}</span>
              <div className="flex-1" />
              <button className="text-xs text-blue-500 hover:text-blue-700" disabled>Ver ↗</button>
              {(canEdit || canPropose) && (
                <button className="text-xs text-slate-400 hover:text-slate-600" disabled>
                  {canEdit ? 'Editar' : 'Propor alteração'}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Histórico */}
      <div>
        <h2 className="text-sm font-semibold text-slate-800 mb-4">Histórico de Alterações</h2>
        <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                <th className="px-5 py-3 text-left">Documento</th>
                <th className="px-5 py-3 text-left">Versão</th>
                <th className="px-5 py-3 text-left">Descrição</th>
                <th className="px-5 py-3 text-left">Autor</th>
                <th className="px-5 py-3 text-left">Data</th>
              </tr>
            </thead>
            <tbody>
              {HISTORICO.map((h) => (
                <tr key={h.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                  <td className="px-5 py-3 text-xs font-medium text-slate-700">{h.doc}</td>
                  <td className="px-5 py-3 text-xs font-mono text-slate-500">v{h.versao}</td>
                  <td className="px-5 py-3 text-xs text-slate-500 max-w-xs">{h.descricao}</td>
                  <td className="px-5 py-3 text-xs text-slate-400">{h.autor}</td>
                  <td className="px-5 py-3 text-xs text-slate-400 whitespace-nowrap">{h.data}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <ScreenNote>
        Esta tela incluirá: editor de documentos com versionamento, fluxo de aprovação para alterações, histórico completo com diff entre versões, e publicação de comunicados oficiais.
      </ScreenNote>
    </div>
  )
}
