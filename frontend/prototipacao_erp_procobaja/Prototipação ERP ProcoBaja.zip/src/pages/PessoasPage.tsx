// Gestão de Pessoas e Participação
// Roles: Capitão, Gestor (full), Líder (own team), Membro (own data only), Orientador (read-only)

import { useState } from 'react'
type Role = string
import { ReadOnlyBanner, ScreenNote } from './EquipePage'

interface Membro {
  id: string
  nome: string
  subarea: string
  presencas: number
  totalReunioes: number
  horasRegistradas: number
  horasMeta: number
  eventos: number
  advertencias: number
  obs: string
}

const MEMBROS: Membro[] = [
  { id: 'M001', nome: 'Ana Souza', subarea: 'Chassis', presencas: 9, totalReunioes: 10, horasRegistradas: 42, horasMeta: 40, eventos: 2, advertencias: 0, obs: '' },
  { id: 'M002', nome: 'Bruno Lima', subarea: 'Motor', presencas: 7, totalReunioes: 10, horasRegistradas: 28, horasMeta: 40, eventos: 1, advertencias: 1, obs: 'Presença baixa em set/26.' },
  { id: 'M003', nome: 'Carla Mendes', subarea: 'Dinâmica', presencas: 10, totalReunioes: 10, horasRegistradas: 55, horasMeta: 40, eventos: 3, advertencias: 0, obs: '' },
  { id: 'M004', nome: 'Diego Costa', subarea: 'TI', presencas: 8, totalReunioes: 10, horasRegistradas: 35, horasMeta: 40, eventos: 2, advertencias: 0, obs: '' },
  { id: 'M005', nome: 'Felipe Rocha', subarea: 'Chassis', presencas: 4, totalReunioes: 10, horasRegistradas: 12, horasMeta: 40, eventos: 0, advertencias: 2, obs: 'Múltiplas ausências sem aviso.' },
  { id: 'M006', nome: 'Gabriela Nunes', subarea: 'Motor', presencas: 9, totalReunioes: 10, horasRegistradas: 38, horasMeta: 40, eventos: 2, advertencias: 0, obs: '' },
]

const REUNIOES = [
  { titulo: 'Reunião Semanal Geral', data: 'Ter, 23 set 2026', hora: '19h00', tipo: 'Obrigatória', presentes: ['M001', 'M002', 'M003', 'M004', 'M006'] },
  { titulo: 'Review Sprint 4', data: 'Sex, 20 set 2026', hora: '18h30', tipo: 'Obrigatória', presentes: ['M001', 'M003', 'M004', 'M005', 'M006'] },
  { titulo: 'Workshop Chassis', data: 'Qua, 18 set 2026', hora: '18h00', tipo: 'Opcional', presentes: ['M001', 'M003'] },
]

interface Props { role?: Role }

export function PessoasPage({ role }: Props) {
  const readOnly = role === 'orientador'
  const isMembro = role === 'membro'
  const [aba, setAba] = useState<'presenca' | 'horas' | 'eventos' | 'advertencias'>('presenca')
  const [membroFoco] = useState<string>('M001') // membro always sees own data

  const dados = isMembro ? MEMBROS.filter((m) => m.id === membroFoco) : MEMBROS

  return (
    <div className="p-6 space-y-6">
      {readOnly && <ReadOnlyBanner />}
      {isMembro && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg px-4 py-2.5 flex items-center gap-2.5">
          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-200 text-blue-700 tracking-widest shrink-0">MEU PERFIL</span>
          <p className="text-xs text-blue-600">Você está visualizando apenas os seus próprios dados de participação.</p>
        </div>
      )}

      {/* KPIs */}
      {!isMembro && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Membros', value: MEMBROS.length },
            { label: 'Média de Presença', value: `${Math.round(MEMBROS.reduce((a, m) => a + (m.presencas / m.totalReunioes) * 100, 0) / MEMBROS.length)}%` },
            { label: 'Total de Horas', value: `${MEMBROS.reduce((a, m) => a + m.horasRegistradas, 0)}h` },
            { label: 'Advertências Abertas', value: MEMBROS.reduce((a, m) => a + m.advertencias, 0) },
          ].map((k) => (
            <div key={k.label} className="bg-white rounded-lg border border-slate-200 p-5">
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{k.label}</p>
              <p className="text-2xl font-semibold text-slate-900 mt-2 font-mono">{k.value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Abas */}
      <div className="flex gap-1 border-b border-slate-200">
        {([['presenca', 'Presenças'], ['horas', 'Carga Horária'], ['eventos', 'Eventos'], ['advertencias', 'Observações']] as const).map(([id, label]) => (
          <button key={id} onClick={() => setAba(id)} className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${aba === id ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
            {label}
          </button>
        ))}
      </div>

      {/* Presenças */}
      {aba === 'presenca' && (
        <div className="space-y-4">
          <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                  <th className="px-5 py-3 text-left">Membro</th>
                  <th className="px-5 py-3 text-left">Subárea</th>
                  <th className="px-5 py-3 text-center">Presenças</th>
                  <th className="px-5 py-3 text-center">Reuniões</th>
                  <th className="px-5 py-3 text-left">Taxa</th>
                </tr>
              </thead>
              <tbody>
                {dados.map((m) => {
                  const pct = Math.round((m.presencas / m.totalReunioes) * 100)
                  return (
                    <tr key={m.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                      <td className="px-5 py-3 text-xs font-medium text-slate-700">{m.nome}</td>
                      <td className="px-5 py-3 text-xs text-slate-400">{m.subarea}</td>
                      <td className="px-5 py-3 text-center text-xs font-mono text-slate-600">{m.presencas}</td>
                      <td className="px-5 py-3 text-center text-xs font-mono text-slate-400">{m.totalReunioes}</td>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${pct}%`, background: pct >= 80 ? '#22c55e' : pct >= 60 ? '#f59e0b' : '#ef4444' }} />
                          </div>
                          <span className="text-xs font-mono text-slate-500">{pct}%</span>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          <h3 className="text-sm font-semibold text-slate-800">Histórico de Reuniões</h3>
          <div className="space-y-3">
            {REUNIOES.map((r, i) => (
              <div key={i} className="bg-white rounded-lg border border-slate-200 p-4">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{r.titulo}</p>
                    <p className="text-xs text-slate-400">{r.data} · {r.hora}</p>
                  </div>
                  <span className={`text-[11px] font-medium px-2 py-0.5 rounded ${r.tipo === 'Obrigatória' ? 'bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-500'}`}>{r.tipo}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {(isMembro ? dados : MEMBROS).map((m) => {
                    const presente = r.presentes.includes(m.id)
                    return (
                      <span key={m.id} className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${presente ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-500'}`}>
                        {m.nome.split(' ')[0]} {presente ? '✓' : '✗'}
                      </span>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Horas */}
      {aba === 'horas' && (
        <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                <th className="px-5 py-3 text-left">Membro</th>
                <th className="px-5 py-3 text-left">Subárea</th>
                <th className="px-5 py-3 text-center">Registradas</th>
                <th className="px-5 py-3 text-center">Meta</th>
                <th className="px-5 py-3 text-left">Progresso</th>
              </tr>
            </thead>
            <tbody>
              {dados.map((m) => {
                const pct = Math.min(Math.round((m.horasRegistradas / m.horasMeta) * 100), 100)
                return (
                  <tr key={m.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="px-5 py-3 text-xs font-medium text-slate-700">{m.nome}</td>
                    <td className="px-5 py-3 text-xs text-slate-400">{m.subarea}</td>
                    <td className="px-5 py-3 text-center font-mono text-xs font-semibold text-slate-700">{m.horasRegistradas}h</td>
                    <td className="px-5 py-3 text-center font-mono text-xs text-slate-400">{m.horasMeta}h</td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full rounded-full bg-blue-500" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="text-xs font-mono text-slate-500">{pct}%</span>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Eventos */}
      {aba === 'eventos' && (
        <div className="bg-white rounded-lg border border-slate-200 p-8 flex flex-col items-center justify-center gap-3">
          <p className="text-sm font-semibold text-slate-400">Participação em Eventos</p>
          <p className="text-xs text-slate-300 text-center max-w-xs">Registro de participação dos membros em competições, workshops e eventos externos. Disponível em breve.</p>
        </div>
      )}

      {/* Advertências */}
      {aba === 'advertencias' && (
        <div className="space-y-3">
          {dados.map((m) => (
            <div key={m.id} className="bg-white rounded-lg border border-slate-200 p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-slate-800">{m.nome}</p>
                {m.advertencias > 0 && (
                  <span className="text-xs font-medium px-2 py-0.5 rounded bg-red-50 text-red-600">{m.advertencias} advertência{m.advertencias !== 1 ? 's' : ''}</span>
                )}
              </div>
              <p className="text-xs text-slate-500">{m.obs || 'Sem observações registradas.'}</p>
            </div>
          ))}
        </div>
      )}

      <ScreenNote>
        Esta tela incluirá: diário de atividades individual, registro de presença em tempo real, lançamento de horas com descrição, registro e histórico de advertências, e participação em eventos externos.
      </ScreenNote>
    </div>
  )
}
