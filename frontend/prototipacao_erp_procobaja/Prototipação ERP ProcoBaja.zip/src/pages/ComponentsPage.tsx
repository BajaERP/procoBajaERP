import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Sidebar } from '../components/Sidebar'
import { TopBar } from '../components/TopBar'
import { type Role, ROLE_KEYS } from '../app/Shell'
import { GridIcon, UsersIcon, TaskIcon, CoinIcon, ClockIcon, BookIcon, TrophyIcon, ShieldIcon, GearIcon } from '../components/icons'
import type { NavGroup } from '../components/Sidebar'

const ROLE_LABELS: Record<Role, string> = {
  capitao: 'Capitão',
  gestor: 'Gestor',
  financeiro: 'Financeiro',
  lider: 'Líder',
  membro: 'Membro',
  orientador: 'Orientador',
}

const PREVIEW_NAV: Record<Role, NavGroup[]> = {
  capitao: [
    { group: 'GERAL', items: [{ id: 'capitao', label: 'Dashboard', icon: GridIcon }] },
    { group: 'GESTÃO', items: [{ id: 'equipe', label: 'Equipe e Subsistemas', icon: UsersIcon }, { id: 'atividades', label: 'Atividades e Sprints', icon: TaskIcon }, { id: 'financeiro', label: 'Financeiro', icon: CoinIcon }, { id: 'pessoas', label: 'Pessoas e Participação', icon: ClockIcon }] },
    { group: 'PROJETO', items: [{ id: 'documentacao', label: 'Documentação', icon: BookIcon }, { id: 'competicoes', label: 'Competições e Eventos', icon: TrophyIcon }, { id: 'governanca', label: 'Governança', icon: ShieldIcon }] },
    { group: 'SISTEMA', items: [{ id: 'configuracoes', label: 'Configurações', icon: GearIcon }] },
  ],
  gestor: [
    { group: 'GERAL', items: [{ id: 'gestor', label: 'Dashboard', icon: GridIcon }] },
    { group: 'GESTÃO', items: [{ id: 'equipe', label: 'Equipe e Subsistemas', icon: UsersIcon }, { id: 'atividades', label: 'Atividades e Sprints', icon: TaskIcon }, { id: 'pessoas', label: 'Pessoas e Participação', icon: ClockIcon }] },
    { group: 'PROJETO', items: [{ id: 'documentacao', label: 'Documentação', icon: BookIcon }, { id: 'competicoes', label: 'Competições e Eventos', icon: TrophyIcon }, { id: 'governanca', label: 'Governança', icon: ShieldIcon }] },
    { group: 'SISTEMA', items: [{ id: 'configuracoes', label: 'Configurações', icon: GearIcon }] },
  ],
  financeiro: [
    { group: 'GERAL', items: [{ id: 'financeiro-dash', label: 'Dashboard', icon: GridIcon }] },
    { group: 'FINANÇAS', items: [{ id: 'financeiro', label: 'Gestão Financeira', icon: CoinIcon }, { id: 'competicoes', label: 'Competições e Eventos', icon: TrophyIcon }] },
    { group: 'PROJETO', items: [{ id: 'documentacao', label: 'Documentação', icon: BookIcon }] },
    { group: 'SISTEMA', items: [{ id: 'configuracoes', label: 'Configurações', icon: GearIcon }] },
  ],
  lider: [
    { group: 'GERAL', items: [{ id: 'lider', label: 'Dashboard', icon: GridIcon }] },
    { group: 'MEU SUBSISTEMA', items: [{ id: 'atividades', label: 'Atividades e Sprints', icon: TaskIcon }, { id: 'pessoas', label: 'Pessoas e Participação', icon: ClockIcon }] },
    { group: 'PROJETO', items: [{ id: 'documentacao', label: 'Documentação', icon: BookIcon }, { id: 'competicoes', label: 'Competições e Eventos', icon: TrophyIcon }] },
    { group: 'SISTEMA', items: [{ id: 'configuracoes', label: 'Configurações', icon: GearIcon }] },
  ],
  membro: [
    { group: 'GERAL', items: [{ id: 'membro', label: 'Dashboard', icon: GridIcon }] },
    { group: 'MINHAS ATIVIDADES', items: [{ id: 'atividades', label: 'Atividades e Sprints', icon: TaskIcon }, { id: 'pessoas', label: 'Minha Participação', icon: ClockIcon }] },
    { group: 'PROJETO', items: [{ id: 'documentacao', label: 'Documentação', icon: BookIcon }, { id: 'competicoes', label: 'Competições e Eventos', icon: TrophyIcon }] },
    { group: 'SISTEMA', items: [{ id: 'configuracoes', label: 'Configurações', icon: GearIcon }] },
  ],
  orientador: [
    { group: 'CONSULTA', items: [{ id: 'orientador', label: 'Dashboard', icon: GridIcon }, { id: 'equipe', label: 'Equipe e Subsistemas', icon: UsersIcon }, { id: 'atividades', label: 'Atividades e Sprints', icon: TaskIcon }, { id: 'financeiro', label: 'Financeiro', icon: CoinIcon }, { id: 'pessoas', label: 'Pessoas e Participação', icon: ClockIcon }, { id: 'documentacao', label: 'Documentação', icon: BookIcon }, { id: 'competicoes', label: 'Competições e Eventos', icon: TrophyIcon }, { id: 'governanca', label: 'Governança', icon: ShieldIcon }] },
    { group: 'SISTEMA', items: [{ id: 'configuracoes', label: 'Configurações', icon: GearIcon }] },
  ],
}

export function ComponentsPage() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <div className="bg-[#0f1729] text-white px-8 py-4 flex items-center gap-4">
        <div className="w-6 h-6 rounded bg-[#2563eb] flex items-center justify-center text-xs font-bold shrink-0">PB</div>
        <span className="text-sm font-semibold tracking-wide">Proco Baja</span>
        <span className="text-white/20 text-sm mx-1">/</span>
        <span className="text-white/50 text-sm">Biblioteca de Componentes</span>
        <div className="ml-auto">
          <Link to="/app/lider" className="text-xs text-white/50 hover:text-white/80 transition-colors">
            ← Voltar ao app
          </Link>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-8 py-10 space-y-16">
        <ComponentSection
          name="Sidebar"
          description="Painel de navegação lateral. Recolhível, suporta grupos de nav, cores personalizadas e rodapé de usuário."
          usage={`<Sidebar
  appName="Proco Baja"
  appAbbr="PB"
  nav={PREVIEW_NAV['lider']}
  activeId={activeId}
  onNavChange={setActiveId}
  user={{ initials: 'PB', name: 'Usuário', role: 'Líder' }}
  accentColor="#2563eb"
  background="#0f1729"
/>`}
        >
          <SidebarPreview />
        </ComponentSection>

        <div className="border-t border-slate-200" />

        <ComponentSection
          name="TopBar"
          description="Barra de navegação superior. Mostra breadcrumbs, título, busca opcional, sino de notificações, botão de ajuda e avatar."
          usage={`<TopBar
  breadcrumbs={[{ label: 'Proco Baja' }, { label: 'Dashboard' }]}
  title="Dashboard"
  showSearch
  showNotifications
  hasNotifications
  showHelp
  user={{ initials: 'PB', name: 'Usuário' }}
/>`}
        >
          <TopBarPreview />
        </ComponentSection>
      </div>
    </div>
  )
}

function ComponentSection({
  name,
  description,
  usage,
  children,
}: {
  name: string
  description: string
  usage: string
  children: React.ReactNode
}) {
  const [showCode, setShowCode] = useState(false)

  return (
    <section className="space-y-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">{name}</h2>
          <p className="text-sm text-slate-500 mt-1">{description}</p>
        </div>
        <button
          onClick={() => setShowCode((v) => !v)}
          className="shrink-0 text-xs font-medium px-3 py-1.5 rounded border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 transition-colors"
        >
          {showCode ? 'Ocultar uso' : 'Ver uso'}
        </button>
      </div>

      {showCode && (
        <pre className="bg-[#0f1729] text-slate-300 text-xs rounded-lg p-5 overflow-x-auto font-mono leading-relaxed">
          {usage}
        </pre>
      )}

      {children}
    </section>
  )
}

function SidebarPreview() {
  const [active, setActive] = useState('lider')
  const [bg, setBg] = useState('#0f1729')
  const [accent, setAccent] = useState('#2563eb')
  const [role, setRole] = useState<Role>('lider')
  const [showUser, setShowUser] = useState(true)
  const [startCollapsed, setStartCollapsed] = useState(false)

  const PRESET_BG = ['#0f1729', '#18181b', '#1a1a2e', '#14532d', '#1e1b4b']
  const PRESET_ACCENT = ['#2563eb', '#7c3aed', '#059669', '#dc2626', '#d97706']

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-6 p-4 bg-white rounded-lg border border-slate-200">
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Perfil</span>
          <div className="flex gap-1.5">
            {(['membro', 'lider', 'financeiro'] as Role[]).map((r) => (
              <button
                key={r}
                onClick={() => { setRole(r); setActive(r === 'membro' ? 'membro' : r === 'lider' ? 'lider' : 'financeiro') }}
                className={`text-xs px-2.5 py-1 rounded border transition-colors ${role === r ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-600 border-slate-200'}`}
              >
                {ROLE_LABELS[r]}
              </button>
            ))}
          </div>
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Fundo</span>
          <div className="flex gap-1.5">
            {PRESET_BG.map((c) => (
              <button key={c} onClick={() => setBg(c)} className="w-6 h-6 rounded border-2 transition-all" style={{ background: c, borderColor: bg === c ? '#2563eb' : 'transparent' }} />
            ))}
          </div>
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Destaque</span>
          <div className="flex gap-1.5">
            {PRESET_ACCENT.map((c) => (
              <button key={c} onClick={() => setAccent(c)} className="w-6 h-6 rounded border-2 transition-all" style={{ background: c, borderColor: accent === c ? '#0f172a' : 'transparent' }} />
            ))}
          </div>
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Usuário</span>
          <Toggle value={showUser} onChange={() => setShowUser((v) => !v)} labels={['Visível', 'Oculto']} />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Recolhido</span>
          <Toggle value={startCollapsed} onChange={() => setStartCollapsed((v) => !v)} labels={['Sim', 'Não']} />
        </label>
      </div>

      <div className="rounded-xl border border-slate-200 overflow-hidden bg-slate-100 flex" style={{ height: 480 }}>
        <Sidebar
          key={`${bg}-${accent}-${startCollapsed}-${role}`}
          appName="Proco Baja"
          appAbbr="PB"
          nav={PREVIEW_NAV[role]}
          activeId={active}
          onNavChange={setActive}
          user={showUser ? { initials: 'PB', name: 'Usuário', role: ROLE_LABELS[role] } : undefined}
          accentColor={accent}
          background={bg}
          defaultCollapsed={startCollapsed}
        />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-slate-400 text-sm select-none">← interaja com a sidebar</p>
        </div>
      </div>
    </div>
  )
}

function TopBarPreview() {
  const [showSearch, setShowSearch] = useState(true)
  const [showHelp, setShowHelp] = useState(true)
  const [showNotifs, setShowNotifs] = useState(true)
  const [hasBadge, setHasBadge] = useState(true)
  const [showUser, setShowUser] = useState(true)
  const [titleText, setTitleText] = useState('Dashboard')

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-6 p-4 bg-white rounded-lg border border-slate-200">
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Título</span>
          <input
            value={titleText}
            onChange={(e) => setTitleText(e.target.value)}
            className="px-2 py-1 rounded border border-slate-200 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-400/30 w-36"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Busca</span>
          <Toggle value={showSearch} onChange={() => setShowSearch((v) => !v)} />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Notificações</span>
          <Toggle value={showNotifs} onChange={() => setShowNotifs((v) => !v)} />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Badge</span>
          <Toggle value={hasBadge} onChange={() => setHasBadge((v) => !v)} />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Ajuda</span>
          <Toggle value={showHelp} onChange={() => setShowHelp((v) => !v)} />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Avatar</span>
          <Toggle value={showUser} onChange={() => setShowUser((v) => !v)} />
        </label>
      </div>

      <div className="rounded-xl border border-slate-200 overflow-hidden shadow-sm">
        <TopBar
          breadcrumbs={[{ label: 'Proco Baja' }, { label: titleText }]}
          title={titleText}
          showSearch={showSearch}
          searchPlaceholder="Buscar…"
          showNotifications={showNotifs}
          hasNotifications={hasBadge}
          showHelp={showHelp}
          user={showUser ? { initials: 'PB', name: 'Usuário' } : undefined}
        />
        <div className="h-20 bg-slate-50 flex items-center justify-center">
          <p className="text-slate-400 text-sm select-none">↑ top bar acima</p>
        </div>
      </div>
    </div>
  )
}

function Toggle({
  value,
  onChange,
  labels = ['Sim', 'Não'],
}: {
  value: boolean
  onChange: () => void
  labels?: [string, string]
}) {
  return (
    <button
      onClick={onChange}
      className={`px-3 py-1 rounded text-xs font-medium border transition-colors ${
        value ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-600 border-slate-200'
      }`}
    >
      {value ? labels[0] : labels[1]}
    </button>
  )
}
