import { useApp } from '../AppContext'
import { useT } from '../translations'

export function ConfiguracoesPage() {
  const { language, theme, setLanguage, setTheme } = useApp()
  const t = useT()

  return (
    <div className="p-6 max-w-2xl space-y-8">
      <div>
        <h1 className="text-lg font-semibold text-slate-900 dark:text-slate-100">{t('settings.title')}</h1>
        <p className="text-sm text-slate-400 dark:text-slate-500 mt-0.5">{t('settings.subtitle')}</p>
      </div>

      {/* Appearance */}
      <section className="space-y-4">
        <h2 className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
          {t('settings.section.appearance')}
        </h2>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-5">
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 mb-0.5">{t('settings.theme.label')}</p>
          <p className="text-xs text-slate-400 dark:text-slate-500 mb-4">{t('settings.theme.desc')}</p>

          <div className="grid grid-cols-2 gap-3">
            <ThemeCard
              active={theme === 'light'}
              onClick={() => setTheme('light')}
              label={t('settings.theme.light')}
              preview={<LightPreview />}
            />
            <ThemeCard
              active={theme === 'dark'}
              onClick={() => setTheme('dark')}
              label={t('settings.theme.dark')}
              preview={<DarkPreview />}
            />
          </div>
        </div>
      </section>

      {/* Language */}
      <section className="space-y-4">
        <h2 className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
          {t('settings.section.language')}
        </h2>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-5">
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 mb-0.5">{t('settings.lang.label')}</p>
          <p className="text-xs text-slate-400 dark:text-slate-500 mb-4">{t('settings.lang.desc')}</p>

          <div className="grid grid-cols-2 gap-3">
            <LangCard
              active={language === 'pt'}
              onClick={() => setLanguage('pt')}
              flag="🇧🇷"
              label={t('settings.lang.pt')}
              sub="Português"
            />
            <LangCard
              active={language === 'en'}
              onClick={() => setLanguage('en')}
              flag="🇺🇸"
              label={t('settings.lang.en')}
              sub="English"
            />
          </div>
        </div>
      </section>

      {/* About */}
      <section className="space-y-4">
        <h2 className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
          {t('settings.section.about')}
        </h2>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-5 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-[#0f1729] flex items-center justify-center shrink-0">
            <span className="text-white text-xs font-bold tracking-tight">PB</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{t('settings.about.name')}</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">{t('settings.about.desc')}</p>
          </div>
          <span className="text-xs font-mono text-slate-300 dark:text-slate-600 shrink-0">
            {t('settings.about.version')} 0.1-proto
          </span>
        </div>
      </section>
    </div>
  )
}

// ── Sub-components ─────────────────────────────────────────────────────

function ThemeCard({ active, onClick, label, preview }: {
  active: boolean
  onClick: () => void
  label: string
  preview: React.ReactNode
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-lg border-2 p-3 text-left transition-all ${
        active
          ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/40'
          : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
      }`}
    >
      <div className="rounded-md overflow-hidden mb-2.5 border border-slate-200 dark:border-slate-700">
        {preview}
      </div>
      <div className="flex items-center gap-2">
        <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center shrink-0 ${
          active ? 'border-blue-500' : 'border-slate-300 dark:border-slate-600'
        }`}>
          {active && <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />}
        </div>
        <span className="text-xs font-medium text-slate-700 dark:text-slate-300">{label}</span>
      </div>
    </button>
  )
}

function LangCard({ active, onClick, flag, label, sub }: {
  active: boolean
  onClick: () => void
  flag: string
  label: string
  sub: string
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-lg border-2 p-4 text-left transition-all flex items-center gap-3 ${
        active
          ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/40'
          : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
      }`}
    >
      <span className="text-2xl shrink-0">{flag}</span>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{label}</p>
        <p className="text-xs text-slate-400 dark:text-slate-500">{sub}</p>
      </div>
      <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center shrink-0 ${
        active ? 'border-blue-500' : 'border-slate-300 dark:border-slate-600'
      }`}>
        {active && <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />}
      </div>
    </button>
  )
}

function LightPreview() {
  return (
    <div className="bg-slate-50 p-2 space-y-1.5">
      <div className="flex gap-1.5">
        <div className="w-6 h-8 rounded bg-[#0f1729]" />
        <div className="flex-1 space-y-1">
          <div className="h-1.5 bg-slate-200 rounded w-3/4" />
          <div className="h-1.5 bg-slate-100 rounded w-1/2" />
          <div className="h-1.5 bg-slate-100 rounded w-2/3" />
        </div>
      </div>
      <div className="bg-white rounded border border-slate-200 p-1.5 space-y-1">
        <div className="h-1 bg-slate-200 rounded w-1/2" />
        <div className="h-1 bg-slate-100 rounded" />
        <div className="h-1 bg-slate-100 rounded w-3/4" />
      </div>
    </div>
  )
}

function DarkPreview() {
  return (
    <div className="bg-slate-900 p-2 space-y-1.5">
      <div className="flex gap-1.5">
        <div className="w-6 h-8 rounded bg-[#0a0f1e]" />
        <div className="flex-1 space-y-1">
          <div className="h-1.5 bg-slate-700 rounded w-3/4" />
          <div className="h-1.5 bg-slate-800 rounded w-1/2" />
          <div className="h-1.5 bg-slate-800 rounded w-2/3" />
        </div>
      </div>
      <div className="bg-slate-800 rounded border border-slate-700 p-1.5 space-y-1">
        <div className="h-1 bg-slate-600 rounded w-1/2" />
        <div className="h-1 bg-slate-700 rounded" />
        <div className="h-1 bg-slate-700 rounded w-3/4" />
      </div>
    </div>
  )
}
