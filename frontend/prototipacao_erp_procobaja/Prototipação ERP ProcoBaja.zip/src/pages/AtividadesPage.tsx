// Gestão de Atividades e Sprints
// Roles: Capitão, Gestor (full), Líder (own subsystem), Membro (own tasks), Orientador (read-only)

// eslint-disable-next-line @typescript-eslint/no-unused-vars
type Role = string
import { ReadOnlyBanner, ScreenNote } from './EquipePage'

type TaskStatus = 'backlog' | 'a-fazer' | 'em-andamento' | 'revisao' | 'concluido'
type Priority = 'Crítica' | 'Alta' | 'Média' | 'Baixa'

interface Tarefa {
  id: string
  titulo: string
  responsavel: string
  subsistema: string
  prioridade: Priority
  esforco: number // story points
  sprint: string
  status: TaskStatus
}

const TAREFAS: Tarefa[] = [
  { id: 'T001', titulo: 'Modelar suporte de suspensão', responsavel: 'Ana Souza', subsistema: 'Chassis', prioridade: 'Alta', esforco: 5, sprint: 'Sprint 4', status: 'em-andamento' },
  { id: 'T002', titulo: 'Integrar sensores CAN bus', responsavel: 'Diego Costa', subsistema: 'TI', prioridade: 'Alta', esforco: 8, sprint: 'Sprint 4', status: 'a-fazer' },
  { id: 'T003', titulo: 'Revisão do projeto 3D do chassi', responsavel: 'Ana Souza', subsistema: 'Chassis', prioridade: 'Média', esforco: 3, sprint: 'Sprint 4', status: 'revisao' },
  { id: 'T004', titulo: 'Documentar testes de bancada', responsavel: 'Bruno Lima', subsistema: 'Motor', prioridade: 'Média', esforco: 2, sprint: 'Sprint 4', status: 'a-fazer' },
  { id: 'T005', titulo: 'Calcular distribuição de peso', responsavel: 'Carla Mendes', subsistema: 'Dinâmica', prioridade: 'Crítica', esforco: 8, sprint: 'Sprint 4', status: 'em-andamento' },
  { id: 'T006', titulo: 'Entregar relatório semanal', responsavel: 'Eduarda Pires', subsistema: 'Gestão', prioridade: 'Alta', esforco: 1, sprint: 'Sprint 4', status: 'concluido' },
  { id: 'T007', titulo: 'Atualizar backlog do motor', responsavel: 'Bruno Lima', subsistema: 'Motor', prioridade: 'Baixa', esforco: 2, sprint: 'Backlog', status: 'backlog' },
  { id: 'T008', titulo: 'Protótipo sistema de freios', responsavel: 'Thiago Alves', subsistema: 'Chassis', prioridade: 'Alta', esforco: 13, sprint: 'Backlog', status: 'backlog' },
]

const SPRINTS = [
  { id: 'S04', nome: 'Sprint 4 – Integração', inicio: '16 set 2026', fim: '30 set 2026', ativo: true, total: 27, concluido: 9 },
  { id: 'S03', nome: 'Sprint 3 – Montagem', inicio: '01 set 2026', fim: '15 set 2026', ativo: false, total: 21, concluido: 21 },
  { id: 'S02', nome: 'Sprint 2 – Prototipagem', inicio: '15 ago 2026', fim: '31 ago 2026', ativo: false, total: 18, concluido: 18 },
]

const COLUNAS: { id: TaskStatus; label: string }[] = [
  { id: 'backlog', label: 'Backlog' },
  { id: 'a-fazer', label: 'A Fazer' },
  { id: 'em-andamento', label: 'Em Andamento' },
  { id: 'revisao', label: 'Revisão' },
  { id: 'concluido', label: 'Concluído' },
]

const PRIORITY_COLOR: Record<Priority, string> = {
  Crítica: 'bg-red-100 text-red-700',
  Alta: 'bg-red-50 text-red-600',
  Média: 'bg-amber-50 text-amber-600',
  Baixa: 'bg-slate-100 text-slate-500',
}

interface Props { role?: Role }

export function AtividadesPage({ role }: Props) {
  const readOnly = role === 'orientador'
  const isMembro = role === 'membro'
  const tarefasVisiveis = isMembro ? TAREFAS.filter((t) => t.responsavel === 'Ana Souza') : TAREFAS

  return (
    <div className="p-6 space-y-6">
      {readOnly && <ReadOnlyBanner />}

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Sprint Ativo', value: 'Sprint 4' },
          { label: 'Tarefas no Sprint', value: tarefasVisiveis.filter((t) => t.sprint === 'Sprint 4').length },
          { label: 'Concluídas', value: tarefasVisiveis.filter((t) => t.status === 'concluido').length },
          { label: 'No Backlog', value: tarefasVisiveis.filter((t) => t.status === 'backlog').length },
        ].map((k) => (
          <div key={k.label} className="bg-white rounded-lg border border-slate-200 p-5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{k.label}</p>
            <p className="text-2xl font-semibold text-slate-900 mt-2 font-mono">{k.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Kanban */}
        <div className="lg:col-span-3 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-800">Quadro Kanban — Sprint 4</h2>
            {!readOnly && !isMembro && (
              <button className="text-xs font-medium px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors" disabled>
                + Nova tarefa
              </button>
            )}
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {COLUNAS.map((col) => {
              const cards = tarefasVisiveis.filter((t) => t.status === col.id)
              return (
                <div key={col.id} className="bg-white rounded-lg border border-slate-200 overflow-hidden shrink-0 w-52">
                  <div className="px-3 py-2.5 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-600 uppercase tracking-wide">{col.label}</span>
                    <span className="text-xs font-mono text-slate-400">{cards.length}</span>
                  </div>
                  <div className="p-2 space-y-2 min-h-[100px]">
                    {cards.map((t) => (
                      <div key={t.id} className="bg-slate-50 rounded border border-slate-100 p-2.5">
                        <p className="text-xs font-semibold text-slate-700 leading-snug mb-1.5">{t.titulo}</p>
                        <p className="text-[10px] text-slate-400 mb-1.5">{t.responsavel} · {t.subsistema}</p>
                        <div className="flex items-center justify-between">
                          <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${PRIORITY_COLOR[t.prioridade]}`}>{t.prioridade}</span>
                          <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1 py-0.5 rounded">{t.esforco}pt</span>
                        </div>
                      </div>
                    ))}
                    {cards.length === 0 && <p className="text-xs text-slate-300 text-center py-3">Vazio</p>}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Sprints */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-800">Sprints</h2>
            {!readOnly && !isMembro && role !== 'membro' && (
              <button className="text-xs font-medium px-2 py-1 rounded bg-blue-600 text-white hover:bg-blue-700 transition-colors" disabled>+ Novo</button>
            )}
          </div>
          {SPRINTS.map((s) => {
            const pct = Math.round((s.concluido / s.total) * 100)
            return (
              <div key={s.id} className="bg-white rounded-lg border border-slate-200 p-4">
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-xs font-semibold text-slate-700">{s.nome}</p>
                  {s.ativo && <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-50 text-blue-600 font-medium">Ativo</span>}
                </div>
                <p className="text-[11px] text-slate-400 mb-2">{s.inicio} → {s.fim}</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-blue-500" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">{pct}%</span>
                </div>
                <p className="text-[10px] text-slate-300 mt-1">{s.concluido}/{s.total} pts</p>
              </div>
            )
          })}
        </div>
      </div>

      <ScreenNote>
        Esta tela incluirá: backlog completo com filtros, criação e edição de tarefas com estimativa de esforço, gestão de sprints com velocidade do time e burndown chart.
      </ScreenNote>
    </div>
  )
}
