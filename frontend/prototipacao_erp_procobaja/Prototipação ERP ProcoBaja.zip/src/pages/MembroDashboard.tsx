import { useState } from 'react'

type TaskStatus = 'a-fazer' | 'em-andamento' | 'concluido'

interface Tarefa {
  id: string
  titulo: string
  subtitulo: string
  prioridade: 'Alta' | 'Média' | 'Baixa'
  status: TaskStatus
}

interface RegistroHora {
  id: string
  data: string
  horas: number
  descricao: string
}

interface EntradaDiario {
  id: string
  data: string
  titulo: string
  conteudo: string
}

interface Reuniao {
  titulo: string
  data: string
  hora: string
  obrigatoria: boolean
  confirmado: boolean
}

const TAREFAS_INICIAIS: Tarefa[] = [
  { id: 't1', titulo: 'Modelar suporte de suspensão', subtitulo: 'Chassis — CAD', prioridade: 'Alta', status: 'a-fazer' },
  { id: 't2', titulo: 'Documentar testes de bancada', subtitulo: 'Motor — Relatório', prioridade: 'Média', status: 'a-fazer' },
  { id: 't3', titulo: 'Revisar cálculo de peso total', subtitulo: 'Dinâmica', prioridade: 'Alta', status: 'em-andamento' },
  { id: 't4', titulo: 'Atualizar planilha de peças', subtitulo: 'Estoque', prioridade: 'Baixa', status: 'em-andamento' },
  { id: 't5', titulo: 'Entregar relatório semanal', subtitulo: 'Gestão', prioridade: 'Alta', status: 'concluido' },
]

const HORAS_INICIAIS: RegistroHora[] = [
  { id: 'h1', data: '23 set 2026', horas: 3, descricao: 'Reunião semanal + ata' },
  { id: 'h2', data: '22 set 2026', horas: 4, descricao: 'Modelagem CAD suporte' },
  { id: 'h3', data: '20 set 2026', horas: 2.5, descricao: 'Review Sprint 4' },
  { id: 'h4', data: '18 set 2026', horas: 5, descricao: 'Testes de bancada motor' },
]

const DIARIO_INICIAL: EntradaDiario[] = [
  { id: 'd1', data: '23 set 2026', titulo: 'Reunião semanal', conteudo: 'Participei da reunião semanal do time. Discutimos o andamento da Sprint 4 e alinhamos as próximas entregas. Fui designado para finalizar o suporte de suspensão.' },
  { id: 'd2', data: '20 set 2026', titulo: 'Progresso no CAD', conteudo: 'Avancei bastante na modelagem do suporte. Preciso validar as dimensões com o Thiago antes de finalizar.' },
]

const REUNIOES_INICIAIS: Reuniao[] = [
  { titulo: 'Reunião Semanal Geral', data: 'Ter, 25 set 2026', hora: '19h00', obrigatoria: true, confirmado: true },
  { titulo: 'Review Sprint 4', data: 'Sex, 28 set 2026', hora: '18h30', obrigatoria: true, confirmado: false },
  { titulo: 'Workshop CAD', data: 'Qua, 01 out 2026', hora: '17h00', obrigatoria: false, confirmado: false },
]

const PRIORIDADE_COLOR: Record<string, string> = {
  Alta: 'bg-red-50 text-red-600',
  Média: 'bg-amber-50 text-amber-600',
  Baixa: 'bg-slate-100 text-slate-500',
}

const COLUNAS: { id: TaskStatus; label: string }[] = [
  { id: 'a-fazer', label: 'A Fazer' },
  { id: 'em-andamento', label: 'Em Andamento' },
  { id: 'concluido', label: 'Concluído' },
]

export function MembroDashboard() {
  const [tarefas, setTarefas] = useState(TAREFAS_INICIAIS)
  const [horas, setHoras] = useState(HORAS_INICIAIS)
  const [diario, setDiario] = useState(DIARIO_INICIAL)
  const [reunioes, setReunioes] = useState(REUNIOES_INICIAIS)
  const [aba, setAba] = useState<'kanban' | 'presenca' | 'horas' | 'diario'>('kanban')

  // Forms
  const [showTaskForm, setShowTaskForm] = useState(false)
  const [novaTarefa, setNovaTarefa] = useState({ titulo: '', subtitulo: '', prioridade: 'Média' as Tarefa['prioridade'] })
  const [showHoraForm, setShowHoraForm] = useState(false)
  const [novaHora, setNovaHora] = useState({ data: '', horas: '', descricao: '' })
  const [showDiarioForm, setShowDiarioForm] = useState(false)
  const [novaDiario, setNovaDiario] = useState({ titulo: '', conteudo: '' })

  const totalHoras = horas.reduce((acc, h) => acc + h.horas, 0)
  const metaHoras = 40

  function moverTarefa(id: string, status: TaskStatus) {
    setTarefas((prev) => prev.map((t) => t.id === id ? { ...t, status } : t))
  }

  function adicionarTarefa(e: React.FormEvent) {
    e.preventDefault()
    setTarefas((prev) => [{ id: `t${Date.now()}`, ...novaTarefa, status: 'a-fazer' }, ...prev])
    setNovaTarefa({ titulo: '', subtitulo: '', prioridade: 'Média' })
    setShowTaskForm(false)
  }

  function registrarHora(e: React.FormEvent) {
    e.preventDefault()
    setHoras((prev) => [{ id: `h${Date.now()}`, ...novaHora, horas: Number(novaHora.horas) }, ...prev])
    setNovaHora({ data: '', horas: '', descricao: '' })
    setShowHoraForm(false)
  }

  function adicionarDiario(e: React.FormEvent) {
    e.preventDefault()
    const agora = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })
    setDiario((prev) => [{ id: `d${Date.now()}`, data: agora, ...novaDiario }, ...prev])
    setNovaDiario({ titulo: '', conteudo: '' })
    setShowDiarioForm(false)
  }

  function togglePresenca(i: number) {
    setReunioes((prev) => prev.map((r, idx) => idx === i ? { ...r, confirmado: !r.confirmado } : r))
  }

  return (
    <div className="p-6 space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Tarefas Abertas', value: tarefas.filter((t) => t.status !== 'concluido').length },
          { label: 'Tarefas Concluídas', value: tarefas.filter((t) => t.status === 'concluido').length },
          { label: 'Horas Registradas', value: `${totalHoras}h` },
          { label: 'Meta de Horas', value: `${metaHoras}h` },
        ].map((k) => (
          <div key={k.label} className="bg-white rounded-lg border border-slate-200 p-5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{k.label}</p>
            <p className="text-2xl font-semibold text-slate-900 mt-2 font-mono">{k.value}</p>
          </div>
        ))}
      </div>

      {/* Abas */}
      <div className="flex gap-1 border-b border-slate-200">
        {([['kanban', 'Minhas Tarefas'], ['presenca', 'Presenças'], ['horas', 'Horas'], ['diario', 'Diário']] as const).map(([id, label]) => (
          <button key={id} onClick={() => setAba(id)} className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${aba === id ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
            {label}
          </button>
        ))}
      </div>

      {/* Kanban */}
      {aba === 'kanban' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button onClick={() => setShowTaskForm((v) => !v)} className="text-xs font-medium px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors">
              {showTaskForm ? 'Cancelar' : '+ Nova tarefa'}
            </button>
          </div>
          {showTaskForm && (
            <form onSubmit={adicionarTarefa} className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap gap-3 items-end">
              <div className="flex-1 min-w-40">
                <label className="block text-xs font-medium text-slate-600 mb-1">Título</label>
                <input required value={novaTarefa.titulo} onChange={(e) => setNovaTarefa({ ...novaTarefa, titulo: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" placeholder="O que fazer?" />
              </div>
              <div className="min-w-32">
                <label className="block text-xs font-medium text-slate-600 mb-1">Subárea</label>
                <input value={novaTarefa.subtitulo} onChange={(e) => setNovaTarefa({ ...novaTarefa, subtitulo: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" placeholder="Ex: Chassis" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Prioridade</label>
                <select value={novaTarefa.prioridade} onChange={(e) => setNovaTarefa({ ...novaTarefa, prioridade: e.target.value as Tarefa['prioridade'] })} className="px-3 py-1.5 rounded border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-400/30">
                  <option>Alta</option><option>Média</option><option>Baixa</option>
                </select>
              </div>
              <button type="submit" className="text-xs px-4 py-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 font-medium h-[30px]">Adicionar</button>
            </form>
          )}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {COLUNAS.map((col) => {
              const cards = tarefas.filter((t) => t.status === col.id)
              return (
                <div key={col.id} className="bg-white rounded-lg border border-slate-200 overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">{col.label}</span>
                    <span className="text-xs font-mono text-slate-400">{cards.length}</span>
                  </div>
                  <div className="p-3 space-y-2 min-h-[120px]">
                    {cards.map((t) => (
                      <div key={t.id} className="bg-slate-50 rounded-md border border-slate-100 p-3 group">
                        <div className="flex items-start justify-between gap-2 mb-1.5">
                          <p className="text-xs font-semibold text-slate-700 leading-snug">{t.titulo}</p>
                          <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded shrink-0 ${PRIORIDADE_COLOR[t.prioridade]}`}>{t.prioridade}</span>
                        </div>
                        {t.subtitulo && <p className="text-[11px] text-slate-400 mb-2">{t.subtitulo}</p>}
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {COLUNAS.filter((c) => c.id !== col.id).map((dest) => (
                            <button key={dest.id} onClick={() => moverTarefa(t.id, dest.id)} className="text-[10px] px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-500 hover:text-blue-600 hover:border-blue-300 transition-colors">→ {dest.label}</button>
                          ))}
                        </div>
                      </div>
                    ))}
                    {cards.length === 0 && <p className="text-xs text-slate-300 text-center py-4">Nenhuma tarefa</p>}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Presenças */}
      {aba === 'presenca' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {reunioes.map((r, i) => (
            <div key={i} className="bg-white rounded-lg border border-slate-200 p-5 flex flex-col gap-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-semibold text-slate-800">{r.titulo}</p>
                  {r.obrigatoria && <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-blue-50 text-blue-600">Obrigatória</span>}
                </div>
                <p className="text-xs text-slate-400">{r.data} · {r.hora}</p>
              </div>
              <button onClick={() => togglePresenca(i)} className={`mt-auto text-xs font-medium px-3 py-1.5 rounded-md border transition-colors ${r.confirmado ? 'bg-green-50 border-green-200 text-green-700' : 'bg-white border-slate-200 text-slate-600 hover:border-blue-300 hover:text-blue-600'}`}>
                {r.confirmado ? '✓ Presença confirmada' : 'Confirmar presença'}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Horas */}
      {aba === 'horas' && (
        <div className="space-y-4">
          <div className="bg-white rounded-lg border border-slate-200 p-5">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-sm font-semibold text-slate-800">Horas do mês</p>
                <p className="text-xs text-slate-400">Meta: {metaHoras}h · Registradas: {totalHoras}h</p>
              </div>
              <button onClick={() => setShowHoraForm((v) => !v)} className="text-xs font-medium px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors">
                {showHoraForm ? 'Cancelar' : '+ Registrar horas'}
              </button>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full bg-blue-500 transition-all" style={{ width: `${Math.min((totalHoras / metaHoras) * 100, 100)}%` }} />
              </div>
              <span className="text-xs font-mono text-slate-500">{Math.round((totalHoras / metaHoras) * 100)}%</span>
            </div>
          </div>

          {showHoraForm && (
            <form onSubmit={registrarHora} className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap gap-3 items-end">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Data</label>
                <input required type="date" value={novaHora.data} onChange={(e) => setNovaHora({ ...novaHora, data: e.target.value })} className="px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Horas</label>
                <input required type="number" min="0.5" max="12" step="0.5" value={novaHora.horas} onChange={(e) => setNovaHora({ ...novaHora, horas: e.target.value })} className="w-20 px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" placeholder="Ex: 2" />
              </div>
              <div className="flex-1 min-w-48">
                <label className="block text-xs font-medium text-slate-600 mb-1">Descrição</label>
                <input required value={novaHora.descricao} onChange={(e) => setNovaHora({ ...novaHora, descricao: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" placeholder="O que foi feito?" />
              </div>
              <button type="submit" className="text-xs px-4 py-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 font-medium h-[30px]">Salvar</button>
            </form>
          )}

          <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide border-b border-slate-100">
                  <th className="px-5 py-3 text-left">Data</th>
                  <th className="px-5 py-3 text-center">Horas</th>
                  <th className="px-5 py-3 text-left">Descrição</th>
                </tr>
              </thead>
              <tbody>
                {horas.map((h) => (
                  <tr key={h.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="px-5 py-3 text-xs text-slate-400 whitespace-nowrap">{h.data}</td>
                    <td className="px-5 py-3 text-center font-mono font-semibold text-slate-700 text-xs">{h.horas}h</td>
                    <td className="px-5 py-3 text-xs text-slate-600">{h.descricao}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Diário */}
      {aba === 'diario' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button onClick={() => setShowDiarioForm((v) => !v)} className="text-xs font-medium px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors">
              {showDiarioForm ? 'Cancelar' : '+ Nova entrada'}
            </button>
          </div>

          {showDiarioForm && (
            <form onSubmit={adicionarDiario} className="bg-white border border-slate-200 rounded-lg p-5 space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Título</label>
                <input required value={novaDiario.titulo} onChange={(e) => setNovaDiario({ ...novaDiario, titulo: e.target.value })} className="w-full px-3 py-1.5 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30" placeholder="Título da entrada" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Conteúdo</label>
                <textarea required value={novaDiario.conteudo} onChange={(e) => setNovaDiario({ ...novaDiario, conteudo: e.target.value })} rows={4} className="w-full px-3 py-2 rounded border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400/30 resize-none" placeholder="Descreva o que foi feito, aprendido ou observado…" />
              </div>
              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => setShowDiarioForm(false)} className="text-xs px-3 py-1.5 rounded border border-slate-200 text-slate-600 hover:bg-slate-50">Cancelar</button>
                <button type="submit" className="text-xs px-4 py-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 font-medium">Salvar entrada</button>
              </div>
            </form>
          )}

          <div className="space-y-3">
            {diario.map((d) => (
              <div key={d.id} className="bg-white rounded-lg border border-slate-200 p-5">
                <div className="flex items-start justify-between mb-2">
                  <p className="text-sm font-semibold text-slate-800">{d.titulo}</p>
                  <span className="text-xs text-slate-400 whitespace-nowrap ml-4">{d.data}</span>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">{d.conteudo}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
