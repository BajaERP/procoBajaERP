import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'

export type Language = 'pt' | 'en'
export type Theme = 'light' | 'dark'

interface AppContextValue {
  language: Language
  theme: Theme
  setLanguage: (l: Language) => void
  setTheme: (t: Theme) => void
}

const AppContext = createContext<AppContextValue>({
  language: 'pt',
  theme: 'light',
  setLanguage: () => {},
  setTheme: () => {},
})

function safeParse<T>(key: string, fallback: T): T {
  try { return (localStorage.getItem(key) as T | null) ?? fallback } catch { return fallback }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [language, setLang] = useState<Language>(() => safeParse('proco-lang', 'pt'))
  const [theme, setThm] = useState<Theme>(() => safeParse('proco-theme', 'light'))

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
  }, [theme])

  function setLanguage(l: Language) {
    try { localStorage.setItem('proco-lang', l) } catch { /* ignore */ }
    setLang(l)
  }

  function setTheme(t: Theme) {
    try { localStorage.setItem('proco-theme', t) } catch { /* ignore */ }
    setThm(t)
  }

  return (
    <AppContext.Provider value={{ language, theme, setLanguage, setTheme }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  return useContext(AppContext)
}
