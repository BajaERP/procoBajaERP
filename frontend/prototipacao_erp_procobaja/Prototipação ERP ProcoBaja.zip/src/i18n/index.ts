import { useApp } from '../contexts/AppContext'

const T = {
  pt: {
    // Nav groups
    'nav.group.geral': 'GERAL',
    'nav.group.gestao': 'GESTÃO',
    'nav.group.projeto': 'PROJETO',
    'nav.group.sistema': 'SISTEMA',
    'nav.group.financas': 'FINANÇAS',
    'nav.group.subsistema': 'MEU SUBSISTEMA',
    'nav.group.atividades': 'MINHAS ATIVIDADES',
    'nav.group.consulta': 'CONSULTA',
    // Nav items
    'nav.dashboard': 'Dashboard',
    'nav.equipe': 'Equipe e Subsistemas',
    'nav.atividades': 'Atividades e Sprints',
    'nav.financeiro': 'Financeiro',
    'nav.gestaoFinanceira': 'Gestão Financeira',
    'nav.pessoas': 'Pessoas e Participação',
    'nav.minhaPart': 'Minha Participação',
    'nav.documentacao': 'Documentação',
    'nav.competicoes': 'Competições e Eventos',
    'nav.governanca': 'Governança',
    'nav.configuracoes': 'Configurações',
    // Dev bar
    'dev.role': 'Perfil (dev)',
    // TopBar
    'topbar.search': 'Buscar…',
    // Route labels (breadcrumbs / page titles)
    'route.dashboard': 'Dashboard',
    'route.equipe': 'Equipe e Subsistemas',
    'route.atividades': 'Atividades e Sprints',
    'route.financeiro': 'Gestão Financeira',
    'route.pessoas': 'Pessoas e Participação',
    'route.documentacao': 'Documentação',
    'route.competicoes': 'Competições e Eventos',
    'route.governanca': 'Governança',
    'route.configuracoes': 'Configurações',
    // Settings page
    'settings.title': 'Configurações',
    'settings.subtitle': 'Preferências da interface',
    'settings.section.appearance': 'Aparência',
    'settings.section.language': 'Idioma',
    'settings.section.about': 'Sobre',
    'settings.theme.label': 'Tema',
    'settings.theme.desc': 'Escolha entre o tema claro ou escuro.',
    'settings.theme.light': 'Claro',
    'settings.theme.dark': 'Escuro',
    'settings.lang.label': 'Idioma da interface',
    'settings.lang.desc': 'Nomes próprios, nome do projeto e dados não são traduzidos.',
    'settings.lang.pt': 'Português',
    'settings.lang.en': 'Inglês',
    'settings.about.name': 'Proco Baja',
    'settings.about.desc': 'Sistema de gestão — versão de protótipo.',
    'settings.about.version': 'Versão',
    // Role labels
    'role.capitao': 'Capitão',
    'role.gestor': 'Gestor',
    'role.financeiro': 'Financeiro',
    'role.lider': 'Líder',
    'role.membro': 'Membro',
    'role.orientador': 'Orientador',
    // Common
    'common.edit': 'Editar',
    'common.save': 'Salvar',
    'common.cancel': 'Cancelar',
    'common.active': 'Ativo',
    'common.inactive': 'Inativo',
    'common.readOnly': 'Somente leitura',
  },
  en: {
    // Nav groups
    'nav.group.geral': 'GENERAL',
    'nav.group.gestao': 'MANAGEMENT',
    'nav.group.projeto': 'PROJECT',
    'nav.group.sistema': 'SYSTEM',
    'nav.group.financas': 'FINANCES',
    'nav.group.subsistema': 'MY SUBSYSTEM',
    'nav.group.atividades': 'MY ACTIVITIES',
    'nav.group.consulta': 'READ-ONLY VIEW',
    // Nav items
    'nav.dashboard': 'Dashboard',
    'nav.equipe': 'Team & Subsystems',
    'nav.atividades': 'Activities & Sprints',
    'nav.financeiro': 'Financial',
    'nav.gestaoFinanceira': 'Financial Management',
    'nav.pessoas': 'People & Participation',
    'nav.minhaPart': 'My Participation',
    'nav.documentacao': 'Documentation',
    'nav.competicoes': 'Competitions & Events',
    'nav.governanca': 'Governance',
    'nav.configuracoes': 'Settings',
    // Dev bar
    'dev.role': 'Role (dev)',
    // TopBar
    'topbar.search': 'Search…',
    // Route labels
    'route.dashboard': 'Dashboard',
    'route.equipe': 'Team & Subsystems',
    'route.atividades': 'Activities & Sprints',
    'route.financeiro': 'Financial Management',
    'route.pessoas': 'People & Participation',
    'route.documentacao': 'Documentation',
    'route.competicoes': 'Competitions & Events',
    'route.governanca': 'Governance',
    'route.configuracoes': 'Settings',
    // Settings page
    'settings.title': 'Settings',
    'settings.subtitle': 'Interface preferences',
    'settings.section.appearance': 'Appearance',
    'settings.section.language': 'Language',
    'settings.section.about': 'About',
    'settings.theme.label': 'Theme',
    'settings.theme.desc': 'Choose between light or dark theme.',
    'settings.theme.light': 'Light',
    'settings.theme.dark': 'Dark',
    'settings.lang.label': 'Interface language',
    'settings.lang.desc': 'Proper names, project name and data are not translated.',
    'settings.lang.pt': 'Portuguese',
    'settings.lang.en': 'English',
    'settings.about.name': 'Proco Baja',
    'settings.about.desc': 'Management system — prototype version.',
    'settings.about.version': 'Version',
    // Role labels
    'role.capitao': 'Captain',
    'role.gestor': 'Manager',
    'role.financeiro': 'Financial',
    'role.lider': 'Leader',
    'role.membro': 'Member',
    'role.orientador': 'Advisor',
    // Common
    'common.edit': 'Edit',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.active': 'Active',
    'common.inactive': 'Inactive',
    'common.readOnly': 'Read only',
  },
} as const

export type TKey = keyof typeof T.pt

export function useT(): (key: TKey) => string {
  const { language } = useApp()
  return (key: TKey) => T[language][key] ?? key
}
