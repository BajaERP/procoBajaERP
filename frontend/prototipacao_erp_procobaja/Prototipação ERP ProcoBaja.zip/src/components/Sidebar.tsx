import { useState } from 'react'
import { ChevronLeftIcon, ChevronRightIcon } from './icons'

export interface NavItem {
  id: string
  label: string
  icon: React.ComponentType
}

export interface NavGroup {
  group: string
  items: NavItem[]
}

export interface SidebarUser {
  initials: string
  name: string
  role: string
}

export interface SidebarProps {
  /** App name shown next to the logo mark */
  appName?: string
  /** Two-letter abbreviation shown in the logo mark */
  appAbbr?: string
  /** Navigation groups */
  nav?: NavGroup[]
  /** Currently active nav item id */
  activeId?: string
  /** Called when a nav item is clicked */
  onNavChange?: (id: string) => void
  /** User shown at the bottom */
  user?: SidebarUser
  /** Start collapsed */
  defaultCollapsed?: boolean
  /** Accent color for logo mark and active indicators (CSS color) */
  accentColor?: string
  /** Background color of the sidebar (CSS color) */
  background?: string
  /** If provided, shows a DEV link at the bottom pointing to this href */
  devHref?: string
}

export function Sidebar({
  appName = 'My App',
  appAbbr = 'MA',
  nav = [],
  activeId,
  onNavChange,
  user,
  defaultCollapsed = false,
  accentColor = '#2563eb',
  background = '#0f1729',
  devHref,
}: SidebarProps) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed)

  return (
    <aside
      className="flex flex-col h-full shrink-0 transition-all duration-200"
      style={{ width: collapsed ? 64 : 240, background }}
    >
      {/* Logo */}
      <div className="flex items-center h-14 px-4 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-2.5">
          <div
            className="w-7 h-7 rounded flex items-center justify-center shrink-0"
            style={{ background: accentColor }}
          >
            <span className="text-white font-bold text-xs tracking-tight">{appAbbr}</span>
          </div>
          {!collapsed && (
            <span className="text-white font-semibold text-sm tracking-wide truncate">
              {appName}
            </span>
          )}
        </div>
        {!collapsed && (
          <button
            onClick={() => setCollapsed(true)}
            className="ml-auto text-white/40 hover:text-white/80 transition-colors"
          >
            <ChevronLeftIcon />
          </button>
        )}
      </div>

      {collapsed && (
        <button
          onClick={() => setCollapsed(false)}
          className="mx-auto mt-3 text-white/40 hover:text-white/80 transition-colors"
        >
          <ChevronRightIcon />
        </button>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 space-y-5">
        {nav.map(({ group, items }) => (
          <div key={group}>
            {!collapsed && (
              <p className="px-4 mb-1 text-[10px] font-semibold tracking-widest text-white/30">
                {group}
              </p>
            )}
            {items.map(({ id, label, icon: Icon }) => {
              const active = activeId === id
              return (
                <button
                  key={id}
                  onClick={() => onNavChange?.(id)}
                  title={collapsed ? label : undefined}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm font-medium transition-colors group
                    ${active
                      ? 'bg-white/10 text-white'
                      : 'text-white/50 hover:text-white/80 hover:bg-white/5'
                    }`}
                >
                  <span
                    className="shrink-0 transition-colors"
                    style={active ? { color: accentColor } : undefined}
                  >
                    <Icon />
                  </span>
                  {!collapsed && <span className="truncate">{label}</span>}
                  {!collapsed && active && (
                    <span
                      className="ml-auto w-1 h-1 rounded-full"
                      style={{ background: accentColor }}
                    />
                  )}
                </button>
              )
            })}
          </div>
        ))}
      </nav>

      {/* User */}
      {user && (
        <div className="shrink-0 border-t border-white/10 px-4 py-3 flex items-center gap-3">
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-white/80 text-xs font-semibold shrink-0"
            style={{ background: '#253670' }}
          >
            {user.initials}
          </div>
          {!collapsed && (
            <div className="overflow-hidden">
              <p className="text-white/80 text-xs font-medium truncate">{user.name}</p>
              <p className="text-white/30 text-[11px] truncate">{user.role}</p>
            </div>
          )}
        </div>
      )}

      {/* DEV link */}
      {devHref && (
        <a
          href={devHref}
          title="Component library"
          className="shrink-0 flex items-center gap-2 px-4 py-2.5 border-t border-white/10 hover:bg-white/5 transition-colors"
        >
          <span className="text-[10px] font-bold tracking-widest px-1.5 py-0.5 rounded bg-white/10 text-white/40">
            DEV
          </span>
          {!collapsed && (
            <span className="text-white/30 text-xs hover:text-white/50 transition-colors">
              Component library
            </span>
          )}
        </a>
      )}
    </aside>
  )
}
