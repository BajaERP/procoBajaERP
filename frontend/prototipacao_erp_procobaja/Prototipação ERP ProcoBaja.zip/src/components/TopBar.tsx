import { BellIcon, HelpIcon, SearchIcon } from './icons'

export interface TopBarBreadcrumb {
  label: string
  href?: string
}

export interface TopBarAction {
  icon: React.ReactNode
  label: string
  badge?: boolean
  onClick?: () => void
}

export interface TopBarUser {
  initials: string
  name?: string
}

export interface TopBarProps {
  breadcrumbs?: TopBarBreadcrumb[]
  title?: string
  showSearch?: boolean
  searchPlaceholder?: string
  onSearch?: (value: string) => void
  actions?: TopBarAction[]
  showNotifications?: boolean
  hasNotifications?: boolean
  onNotificationsClick?: () => void
  showHelp?: boolean
  onHelpClick?: () => void
  user?: TopBarUser
  onUserClick?: () => void
  background?: string
}

export function TopBar({
  breadcrumbs = [],
  title,
  showSearch = true,
  searchPlaceholder = 'Search…',
  onSearch,
  actions = [],
  showNotifications = true,
  hasNotifications = false,
  onNotificationsClick,
  showHelp = true,
  onHelpClick,
  user,
  onUserClick,
}: TopBarProps) {
  return (
    <header className="h-14 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center px-6 gap-4 shrink-0">
      {/* Title area */}
      <div className="flex-1 min-w-0">
        {breadcrumbs.length > 0 && (
          <nav className="text-xs text-slate-400 dark:text-slate-500 flex items-center gap-1.5 truncate">
            {breadcrumbs.map((crumb, i) => (
              <span key={i} className="flex items-center gap-1.5">
                {i > 0 && <span>/</span>}
                {crumb.href
                  ? <a href={crumb.href} className="hover:text-slate-600 dark:hover:text-slate-300 transition-colors">{crumb.label}</a>
                  : <span>{crumb.label}</span>
                }
              </span>
            ))}
          </nav>
        )}
        {title && (
          <h1 className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{title}</h1>
        )}
      </div>

      {/* Search */}
      {showSearch && (
        <div className="relative hidden md:block">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-3.5 h-3.5" />
          <input
            type="text"
            placeholder={searchPlaceholder}
            onChange={(e) => onSearch?.(e.target.value)}
            className="w-60 pl-8 pr-3 py-1.5 rounded-md border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 text-sm text-slate-700 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all"
          />
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center gap-2">
        {actions.map((action, i) => (
          <button
            key={i}
            onClick={action.onClick}
            title={action.label}
            className="relative p-2 rounded-md text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
            {action.icon}
            {action.badge && (
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-red-500 rounded-full" />
            )}
          </button>
        ))}

        {showNotifications && (
          <button
            onClick={onNotificationsClick}
            title="Notifications"
            className="relative p-2 rounded-md text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
            <BellIcon />
            {hasNotifications && (
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-red-500 rounded-full" />
            )}
          </button>
        )}

        {showHelp && (
          <button
            onClick={onHelpClick}
            title="Help"
            className="p-2 rounded-md text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
            <HelpIcon />
          </button>
        )}

        {user && (
          <button
            onClick={onUserClick}
            title={user.name}
            className="w-7 h-7 rounded-full bg-[#0f1729] flex items-center justify-center text-white text-xs font-semibold ml-1 hover:opacity-80 transition-opacity"
          >
            {user.initials}
          </button>
        )}
      </div>
    </header>
  )
}
