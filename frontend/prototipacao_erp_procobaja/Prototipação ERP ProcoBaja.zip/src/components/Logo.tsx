// Proco Baja — logo mark and full lockup
// Hexagonal badge (flat-top) — engineering/precision register

interface LogoMarkProps {
  size?: number
  className?: string
}

export function LogoMark({ size = 64, className }: LogoMarkProps) {
  // Flat-top hexagon, r=0.44×size, centered on size/2
  const s = size
  const cx = s / 2
  const cy = s / 2
  const r = s * 0.44
  // 6 vertices starting at top (-90°), stepping 60°
  const pts = Array.from({ length: 6 }, (_, i) => {
    const a = (Math.PI / 3) * i - Math.PI / 2
    return `${+(cx + r * Math.cos(a)).toFixed(2)},${+(cy + r * Math.sin(a)).toFixed(2)}`
  }).join(' ')

  const id = `clip-${size}`
  const fs = s * 0.30  // font size
  const stripe = s * 0.11

  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} className={className} aria-label="Proco Baja logo">
      <defs>
        <clipPath id={id}>
          <polygon points={pts} />
        </clipPath>
      </defs>
      {/* Hexagon body */}
      <polygon points={pts} fill="#0f1729" />
      {/* Diagonal speed stripe */}
      <rect
        x={cx - stripe * 0.6}
        y={0}
        width={stripe}
        height={s}
        fill="#2563eb"
        opacity={0.18}
        clipPath={`url(#${id})`}
      />
      {/* Border */}
      <polygon points={pts} fill="none" stroke="#2563eb" strokeWidth={s * 0.028} />
      {/* Monogram */}
      <text
        x={cx}
        y={cy + fs * 0.36}
        textAnchor="middle"
        fill="white"
        fontSize={fs}
        fontWeight="700"
        fontFamily="DM Sans, ui-sans-serif, sans-serif"
        letterSpacing={-s * 0.008}
      >
        PB
      </text>
    </svg>
  )
}

interface LogoFullProps {
  markSize?: number
  dark?: boolean
  className?: string
}

export function LogoFull({ markSize = 48, dark = false, className }: LogoFullProps) {
  const textColor = dark ? '#f8fafc' : '#0f1729'
  const subColor = dark ? '#94a3b8' : '#64748b'

  return (
    <div className={`flex items-center gap-3 ${className ?? ''}`}>
      <LogoMark size={markSize} />
      <div>
        <p style={{ color: textColor, fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: markSize * 0.35, lineHeight: 1.1, letterSpacing: '-0.02em' }}>
          PROCO BAJA
        </p>
        <p style={{ color: subColor, fontFamily: 'DM Sans, sans-serif', fontWeight: 500, fontSize: markSize * 0.22, letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 1 }}>
          Sistema de Gestão
        </p>
      </div>
    </div>
  )
}
