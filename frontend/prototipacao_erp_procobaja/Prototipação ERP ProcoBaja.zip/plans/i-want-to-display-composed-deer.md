# Plan: Developer component showcase + multi-screen routing

## Context

The project is a development-stage ERP dashboard. Two reusable components (`Sidebar`, `TopBar`) will appear across many screens. The developer wants to:

1. Preview and interact with those components in isolation — a dedicated "Components" page for dev use
2. Have a clean structure that supports ~9+ additional ERP screens alongside the existing dashboard

Currently there is no router. The component previews (`SidebarPreview`, `TopBarPreview`) live inline inside `App.tsx`, scrollable below the dashboard — not ideal for isolation or scale.

## Approach

Install `react-router-dom` and introduce two top-level route groups:

### Route structure

```
/              → redirects to /app/dashboard
/components    → Component showcase (Sidebar + TopBar in isolation)
/app/:screen   → ERP screens (dashboard, finance, inventory, hr, …)
```

The `/app/*` routes render inside the full shell (`Sidebar` + `TopBar`). The `/components` route renders standalone — no shell wrapping it, so components are truly isolated.

### Files to create / modify

| File | Action |
|---|---|
| `src/main.tsx` | Wrap app in `<BrowserRouter>` |
| `src/App.tsx` | Replace monolithic component with a shell that reads `:screen` param; remove `SidebarPreview` / `TopBarPreview` inline sections |
| `src/pages/ComponentsPage.tsx` | New — developer showcase. Two sections: Sidebar preview (with bg/accent/collapsed controls) and TopBar preview (with prop toggles). Reachable at `/components` |
| `src/pages/DashboardPage.tsx` | New — extract the existing dashboard JSX (KPI cards, table, alerts, quick actions) out of `App.tsx` into its own file |
| `src/router.tsx` | New — define routes using `createBrowserRouter` or `<Routes>` |

`SidebarPreview` and `TopBarPreview` logic moves from `App.tsx` into `ComponentsPage.tsx`. `App.tsx` becomes a thin shell that composes `Sidebar + TopBar + <Outlet>`.

### Navigation between pages

A small "DEV" badge/link in the Sidebar footer (below the user row) links to `/components`. This keeps it out of the main nav but visible to developers. From `/components`, a back-link returns to `/app/dashboard`.

## Verification

1. Visit `/` → redirects to dashboard, full shell renders
2. Click DEV link → navigates to `/components`, no sidebar/topbar shell visible, both component previews render with working controls
3. Back link from components page → returns to dashboard
4. Adding a new screen later = add a route entry + a new page file, no changes to shell
